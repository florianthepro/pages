<?php
/**
 * Nexus – Einstiegspunkt, Setup & Selbst-Installer.
 *
 * Diese eine Datei genügt im Webroot:
 *   • Liegen src/ und apps/ daneben  -> normaler Betrieb (Front Controller).
 *   • Fehlen sie                     -> Installer-Seite, die die App aus dem
 *                                       Repo lädt (oder eine FTP-Anleitung zeigt),
 *                                       statt mit einem Fatal Error abzubrechen.
 *
 * Voraussetzung: Apache + PHP (>= 7.4, pdo_sqlite). Mehr nicht.
 */
declare(strict_types=1);

/* ------- Repo-Konfiguration für den Selbst-Installer ------- */
const NX_REPO   = 'florianthepro/claude';   // owner/repo
const NX_BRANCH = 'nexus';                    // Branch mit der App

$bootstrap = __DIR__ . '/src/bootstrap.php';

/* ===================================================================
 *  BETRIEBSMODUS – alle Dateien vorhanden
 * =================================================================== */
if (is_file($bootstrap)) {
    require $bootstrap;

    // Statische Assets (CSS/JS) über setup.php ausliefern.
    if (isset($_GET['asset'])) {
        $which = ($_GET['asset'] === 'js') ? 'js' : 'css';
        header('Content-Type: ' . ($which === 'js' ? 'application/javascript' : 'text/css') . '; charset=utf-8');
        header('Cache-Control: public, max-age=86400');
        header('X-Content-Type-Options: nosniff');
        readfile(NX_SRC . '/assets/app.' . $which);
        exit;
    }

    if ($missing = nx_requirements()) {
        nx_setup_page($missing);
        exit;
    }

    nx_bootstrap();
    Nexus\Core\Kernel::handle();
    exit;
}

/* ===================================================================
 *  INSTALLER-MODUS – src/ fehlt
 * =================================================================== */
nxi_main();

/* ---- Installer (vollständig eigenständig, ohne src/) -------------- */
function nxi_main(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && ($_POST['do'] ?? '') === 'install') {
        [$ok, $msg] = nxi_install(trim((string)($_POST['token'] ?? '')));
        if ($ok) {
            header('Location: ' . strtok($_SERVER['REQUEST_URI'] ?? 'setup.php', '?'));
            exit;
        }
        nxi_page($msg);
        return;
    }
    nxi_page(null);
}

/** Lädt den Branch als Archiv und entpackt src/ + apps/ neben setup.php. */
function nxi_install(string $token): array
{
    if (!is_writable(__DIR__)) {
        return [false, 'Verzeichnis ist nicht beschreibbar. Bitte src/ und apps/ manuell per FTP hochladen.'];
    }
    $tmp = __DIR__ . '/.nx_install_' . bin2hex(random_bytes(4));
    @mkdir($tmp, 0770, true);

    try {
        // Bevorzugt ZIP (ZipArchive), sonst TAR.GZ (PharData).
        if (class_exists('ZipArchive')) {
            $url  = 'https://api.github.com/repos/' . NX_REPO . '/zipball/' . NX_BRANCH;
            $file = $tmp . '/app.zip';
            nxi_download($url, $file, $token);
            $zip = new ZipArchive();
            if ($zip->open($file) !== true) {
                throw new RuntimeException('ZIP-Archiv konnte nicht geöffnet werden.');
            }
            $zip->extractTo($tmp);
            $zip->close();
        } elseif (class_exists('PharData')) {
            $url  = 'https://api.github.com/repos/' . NX_REPO . '/tarball/' . NX_BRANCH;
            $file = $tmp . '/app.tar.gz';
            nxi_download($url, $file, $token);
            (new PharData($file))->extractTo($tmp, null, true);
        } else {
            throw new RuntimeException('Weder ZipArchive noch PharData verfügbar – bitte src/ und apps/ manuell hochladen.');
        }

        // Top-Verzeichnis im Archiv finden (z. B. florianthepro-claude-<sha>/)
        $top = null;
        foreach (scandir($tmp) ?: [] as $e) {
            if ($e !== '.' && $e !== '..' && is_dir($tmp . '/' . $e) && is_dir($tmp . '/' . $e . '/src')) {
                $top = $tmp . '/' . $e;
                break;
            }
        }
        if ($top === null) {
            throw new RuntimeException('App-Ordner im Archiv nicht gefunden.');
        }

        foreach (['src', 'apps'] as $dir) {
            if (!is_dir($top . '/' . $dir)) {
                throw new RuntimeException("Ordner $dir fehlt im Archiv.");
            }
            nxi_move($top . '/' . $dir, __DIR__ . '/' . $dir);
        }
    } catch (\Throwable $e) {
        nxi_rrmdir($tmp);
        return [false, $e->getMessage()];
    }

    nxi_rrmdir($tmp);
    if (!is_file(__DIR__ . '/src/bootstrap.php')) {
        return [false, 'Installation unvollständig – src/bootstrap.php fehlt weiterhin.'];
    }
    return [true, 'ok'];
}

/** Datei herunterladen (cURL bevorzugt, sonst Streams). */
function nxi_download(string $url, string $dest, string $token): void
{
    $ua = 'Nexus-Installer';
    $headers = ['User-Agent: ' . $ua, 'Accept: application/vnd.github+json'];
    if ($token !== '') {
        $headers[] = 'Authorization: Bearer ' . $token;
    }

    if (function_exists('curl_init')) {
        $fp = fopen($dest, 'wb');
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_FILE           => $fp,
            CURLOPT_FOLLOWLOCATION => true,   // api -> codeload (Auth wird dabei fallengelassen)
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_TIMEOUT        => 60,
            CURLOPT_FAILONERROR    => true,
        ]);
        $ok   = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);
        fclose($fp);
        if ($ok === false || $code >= 400) {
            @unlink($dest);
            throw new RuntimeException(nxi_http_hint((int)$code, $err));
        }
        return;
    }

    if (ini_get('allow_url_fopen')) {
        $ctx = stream_context_create(['http' => ['header' => implode("\r\n", $headers), 'timeout' => 60, 'follow_location' => 1]]);
        $data = @file_get_contents($url, false, $ctx);
        if ($data === false) {
            throw new RuntimeException('Download fehlgeschlagen (allow_url_fopen). Prüfe Token/Netzwerk oder lade manuell hoch.');
        }
        file_put_contents($dest, $data);
        return;
    }

    throw new RuntimeException('Kein Download möglich (weder cURL noch allow_url_fopen). Bitte src/ und apps/ manuell hochladen.');
}

function nxi_http_hint(int $code, string $err): string
{
    if ($code === 401 || $code === 403) {
        return 'Zugriff verweigert (HTTP ' . $code . ') – das Repo ist privat. Gültigen GitHub-Token mit Contents-Read-Rechten eingeben (oder das Repo öffentlich machen).';
    }
    if ($code === 404) {
        return 'Nicht gefunden (HTTP 404) – Repo/Branch prüfen oder Token ohne Zugriff.';
    }
    return 'Download fehlgeschlagen' . ($code ? ' (HTTP ' . $code . ')' : '') . ($err ? ': ' . $err : '') . '.';
}

/** Verzeichnis verschieben (rename, sonst rekursiv kopieren). */
function nxi_move(string $from, string $to): void
{
    if (@rename($from, $to)) {
        return;
    }
    @mkdir($to, 0770, true);
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($from, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    foreach ($it as $item) {
        $target = $to . '/' . $it->getSubPathName();
        $item->isDir() ? @mkdir($target, 0770, true) : @copy($item->getPathname(), $target);
    }
}

function nxi_rrmdir(string $dir): void
{
    if (!is_dir($dir)) {
        return;
    }
    foreach (array_diff(scandir($dir) ?: [], ['.', '..']) as $f) {
        $p = $dir . '/' . $f;
        is_dir($p) ? nxi_rrmdir($p) : @unlink($p);
    }
    @rmdir($dir);
}

/** Installer-Seite (eigenes, minimales Layout – src/ ist ja nicht da). */
function nxi_page(?string $error): void
{
    $php   = version_compare(PHP_VERSION, '7.4.0', '>=');
    $pdo   = extension_loaded('pdo_sqlite');
    $arch  = class_exists('ZipArchive') || class_exists('PharData');
    $net   = function_exists('curl_init') || ini_get('allow_url_fopen');
    $write = is_writable(__DIR__);
    $ready = $php && $pdo && $arch && $net && $write;
    $row = static fn(bool $ok, string $label): string =>
        '<li class="' . ($ok ? 'ok' : 'no') . '">' . ($ok ? '✓' : '✗') . ' ' . $label . '</li>';

    http_response_code($error ? 500 : 200);
    header('Content-Type: text/html; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    echo '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
    echo '<title>Nexus – Installation</title><style>'
       . 'body{font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif;background:#0f1115;color:#cfd3d9;display:grid;place-items:center;min-height:100vh;margin:0;padding:20px}'
       . '.c{width:100%;max-width:480px;background:#171a1f;border:1px solid #2a2e35;border-radius:6px;padding:26px}'
       . 'h1{font-size:18px;margin:0 0 4px}.sub{color:#848a94;font-size:13px;margin:0 0 18px}'
       . 'ul{list-style:none;padding:0;margin:0 0 18px;font-size:13px}li{margin:7px 0}.ok{color:#4a9d6f}.no{color:#c25a5a}'
       . 'label{display:block;font-size:12.5px;color:#848a94;margin:0 0 5px}'
       . 'input{width:100%;box-sizing:border-box;padding:9px 11px;border-radius:4px;border:1px solid #2a2e35;background:#141619;color:#cfd3d9;font-size:13.5px;margin-bottom:6px}'
       . '.btn{width:100%;padding:10px;border:1px solid #4d7ea8;background:#4d7ea8;color:#fff;border-radius:4px;font-weight:600;cursor:pointer;font-size:14px;margin-top:8px}'
       . '.err{background:rgba(194,90,90,.12);border:1px solid rgba(194,90,90,.45);color:#c25a5a;padding:10px 12px;border-radius:4px;font-size:13px;margin-bottom:16px}'
       . 'code{font-family:ui-monospace,Menlo,Consolas,monospace;color:#b3893f;font-size:12px}'
       . 'details{margin-top:14px;font-size:12.5px;color:#848a94}summary{cursor:pointer;color:#4d7ea8}'
       . '.hint{font-size:12px;color:#5a606b;margin-top:4px}</style>';
    echo '<div class="c"><h1>Nexus – Installation</h1>';
    echo '<p class="sub">Die App-Dateien (<code>src/</code>, <code>apps/</code>) fehlen neben dieser <code>setup.php</code>.</p>';
    if ($error) {
        echo '<div class="err">' . htmlspecialchars($error, ENT_QUOTES) . '</div>';
    }
    echo '<ul>';
    echo $row($php,  'PHP ≥ 7.4 (' . PHP_VERSION . ')');
    echo $row($pdo,  'Erweiterung pdo_sqlite');
    echo $row($arch, 'ZipArchive oder PharData (Entpacken)');
    echo $row($net,  'cURL oder allow_url_fopen (Download)');
    echo $row($write,'Verzeichnis beschreibbar');
    echo '</ul>';

    if ($ready) {
        echo '<form method="post">';
        echo '<input type="hidden" name="do" value="install">';
        echo '<label>GitHub-Token <span class="hint">(nötig, da das Repo privat ist – Scope: <code>Contents: read</code>)</span></label>';
        echo '<input type="password" name="token" placeholder="ghp_… / github_pat_…" autocomplete="off">';
        echo '<div class="hint">Leer lassen, falls das Repo öffentlich ist.</div>';
        echo '<button class="btn" type="submit">Aus dem Repo installieren</button>';
        echo '</form>';
    } else {
        echo '<div class="err">Voraussetzungen für die automatische Installation nicht erfüllt.</div>';
    }

    echo '<details><summary>Alternative: manuell per FTP</summary>'
       . '<p>Lade aus dem Branch <code>' . NX_BRANCH . '</code> die Ordner <code>src/</code> und <code>apps/</code> '
       . '(sowie optional <code>old/</code>) in dasselbe Verzeichnis wie diese <code>setup.php</code>. Danach Seite neu laden.</p></details>';
    echo '</div>';
}
