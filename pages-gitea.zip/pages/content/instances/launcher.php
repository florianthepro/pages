<?php
declare(strict_types=1);
///////////////////////
$launcher_title='Launcher';
$launcher_theme='auto'; #'light' (fix hell) | 'dark' (fix dunkel) | 'auto' (dynamisch, folgt System)
$launcher_iconmode='auto'; #'favicon' (Icon = Favicon der Ziel-URL) | 'folder' (aus $launcher_iconbase) | 'auto' (Ordner falls gesetzt, sonst Favicon)
$launcher_iconbase='https://gitea.getitsec.com/florianthepro/pages/raw/branch/main/content/media/launcher/icons/'; #nur bei mode 'folder'/'auto': Dateiname = Kachel-Titel
$launcher_iconext='.ico';
$launcher_links=[ #Platzhalter, durch eigene ersetzen (group + url, optional title/icon)
  ['group'=>'general', 'title'=>'Gitea',     'url'=>'https://gitea.getitsec.com/'],
  ['group'=>'general', 'title'=>'Wikipedia', 'url'=>'https://www.wikipedia.org/'],
  ['group'=>'general', 'title'=>'Proton',    'url'=>'https://proton.me/'],
  ['group'=>'tools',   'title'=>'Excalidraw','url'=>'https://excalidraw.com/'],
  ['group'=>'tools',   'title'=>'PHP',       'url'=>'https://www.php.net/'],
  ['group'=>'tools',   'title'=>'MDN',       'url'=>'https://developer.mozilla.org/'],
  ['group'=>'media',   'title'=>'YouTube',   'url'=>'https://www.youtube.com/'],
  ['group'=>'media',   'title'=>'Wikimedia', 'url'=>'https://commons.wikimedia.org/'],
];

$sharedVars=get_defined_vars();

$yaml=<<<'YAML'
license: "https://gitea.getitsec.com/florianthepro/pages/raw/branch/main/LICENSE"
blocked: "https://gitea.getitsec.com/florianthepro/pages/raw/branch/main/content/instances/blocked.html"
index: "https://gitea.getitsec.com/florianthepro/pages/raw/branch/main/content/routes/launcher/index.php"
YAML;
///////////////////////
$__loaderUrl='https://gitea.getitsec.com/florianthepro/pages/raw/branch/main/content/loader/loader.php';
$__loaderFile=rtrim(sys_get_temp_dir(),'/').'/pages_loader_'.substr(sha1(__DIR__),0,10).'.php';
if(!is_file($__loaderFile)||time()-(int)@filemtime($__loaderFile)>86400){
$__loaderCode=@file_get_contents($__loaderUrl);
if($__loaderCode===false&&function_exists('curl_init')){$__ch=curl_init($__loaderUrl);curl_setopt_array($__ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_TIMEOUT=>20]);$__loaderCode=curl_exec($__ch);curl_close($__ch);}
if(is_string($__loaderCode)&&strpos($__loaderCode,'app_run_remote_script')!==false){@file_put_contents($__loaderFile,$__loaderCode,LOCK_EX);@chmod($__loaderFile,0600);}
}
if(!is_file($__loaderFile)){http_response_code(500);exit('Loader konnte nicht geladen/gespeichert werden.');}
require $__loaderFile;
