<?php
declare(strict_types=1);
if(PHP_VERSION_ID<80000){http_response_code(500);header('Content-Type: text/plain; charset=utf-8');exit('kiosk-dashboard benoetigt PHP 8.0 oder neuer (aktuell: '.PHP_VERSION.').');}
///////////////////////
$kioskdashboard_title='Kiosk Dashboard';
$kioskdashboard_theme='auto'; #'light' (fix hell) | 'dark' (fix dunkel) | 'auto' (dynamisch, folgt System)
$kioskdashboard_datadir='kiosk-dashboard-data'; #Datenordner: name relativ zur Instanz, absoluter Pfad auch moeglich
$kioskdashboard_allow_private_fetch=false; #true erlaubt der fetchHtml-Proxy Zugriffe auf private/interne IPs (SSRF-Risiko)
$kioskdashboard_icon='https://gitea.getitsec.com/florianthepro/pages/raw/branch/main/content/media/kiosk-dashboard/index.svg';
$kioskdashboard_basedir=dirname((string)($_SERVER['SCRIPT_FILENAME']??__FILE__));
if(!preg_match('~^([/\\\\]|[A-Za-z]:)~',$kioskdashboard_datadir))$kioskdashboard_datadir=$kioskdashboard_basedir.DIRECTORY_SEPARATOR.$kioskdashboard_datadir;
$kioskdashboard_jsondir=$kioskdashboard_datadir.DIRECTORY_SEPARATOR.'data.json';

$sharedVars=get_defined_vars();

$yaml=<<<'YAML'
license: "https://gitea.getitsec.com/florianthepro/pages/raw/branch/main/LICENSE"
blocked: "https://gitea.getitsec.com/florianthepro/pages/raw/branch/main/content/instances/blocked.html"
index: "https://gitea.getitsec.com/florianthepro/pages/raw/branch/main/content/routes/kiosk-dashboard/index.php"
edit: "https://gitea.getitsec.com/florianthepro/pages/raw/branch/main/content/routes/kiosk-dashboard/edit.php"
YAML;
///////////////////////
if(!is_dir($kioskdashboard_datadir))@mkdir($kioskdashboard_datadir,0770,true);
if(is_dir($kioskdashboard_datadir)){
if(!is_file($kioskdashboard_datadir.DIRECTORY_SEPARATOR.'.htaccess'))@file_put_contents($kioskdashboard_datadir.DIRECTORY_SEPARATOR.'.htaccess',"<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n");
if(!is_file($kioskdashboard_datadir.DIRECTORY_SEPARATOR.'index.php'))@file_put_contents($kioskdashboard_datadir.DIRECTORY_SEPARATOR.'index.php',"<?php http_response_code(403); exit;");
}
$__loaderUrl='https://gitea.getitsec.com/florianthepro/pages/raw/branch/main/content/loader/loader.php';
$__loaderFile=rtrim(sys_get_temp_dir(),'/').'/pages_loader_'.substr(sha1(__DIR__),0,10).'.php';
if(!is_file($__loaderFile)||time()-(int)@filemtime($__loaderFile)>86400){
$__loaderCode=@file_get_contents($__loaderUrl);
if($__loaderCode===false&&function_exists('curl_init')){$__ch=curl_init($__loaderUrl);curl_setopt_array($__ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_TIMEOUT=>20]);$__loaderCode=curl_exec($__ch);curl_close($__ch);}
if(is_string($__loaderCode)&&strpos($__loaderCode,'app_run_remote_script')!==false){@file_put_contents($__loaderFile,$__loaderCode,LOCK_EX);@chmod($__loaderFile,0600);}
}
if(!is_file($__loaderFile)){http_response_code(500);exit('Loader konnte nicht geladen/gespeichert werden.');}
require $__loaderFile;
