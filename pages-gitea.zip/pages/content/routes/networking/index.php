<?php
if(!preg_match('~^([/\\\\]|[A-Za-z]:)~',(string)$networking_jsondir)){
$__base=isset($appBaseDir)&&is_string($appBaseDir)&&$appBaseDir!==''?$appBaseDir:((string)($_SERVER['SCRIPT_FILENAME']??'')!==''?dirname((string)$_SERVER['SCRIPT_FILENAME']):(string)getcwd());
$networking_jsondir=rtrim($__base,'/\\').DIRECTORY_SEPARATOR.$networking_jsondir;
}
function h($s){return htmlspecialchars((string)$s,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');}
function defaultConfig(){
return[
'typeIcons'=>[],
'serviceLabels'=>[
'BGP'=>'BGP Routing',
'OSPF'=>'OSPF Routing',
'Static-Routing'=>'Statische Route',
'IPsec-VPN'=>'VPN (IPsec)',
'VPN'=>'VPN',
'NTP'=>'Zeitdienst (NTP)',
'SYSLOG'=>'Syslog',
'SNMP'=>'Monitoring (SNMP)',
'HTTPS'=>'HTTPS',
'HTTPS-Admin'=>'HTTPS (Admin)',
'HTTP'=>'HTTP',
'HTTP-Proxy'=>'HTTP Proxy',
'SSH'=>'SSH',
'DNS'=>'DNS',
'SMTP'=>'SMTP',
'RDP'=>'RDP',
'iSCSI'=>'Storage (iSCSI)',
'NFS'=>'Storage (NFS)',
'Backup-Proxy'=>'Backup Proxy',
'Backup-Agent'=>'Backup Agent',
'LDAP'=>'LDAP/AD',
'RADIUS'=>'RADIUS/MFA',
'MSSQL'=>'SQL Server',
'ORACLE-DB'=>'Oracle Datenbank',
'SMB'=>'Dateifreigaben (SMB)',
'CAPWAP'=>'CAPWAP/WLAN',
'Kabel'=>'Kabel (physisch)',
'DEFAULT'=>'Verbindung'
],
'connectionStyles'=>[
'DEFAULT'=>['color'=>'#666666']
],
'vlanGroups'=>[],
'groupStyles'=>[
'Unbekannt'=>['fill'=>'#ffffff','stroke'=>'#d1d5db']
],
'typeStyles'=>[],
'devices'=>[]
];
}
function normalizeConfig($cfg){
$base=defaultConfig();
if(isset($cfg['typeIcons'])&&is_array($cfg['typeIcons']))$base['typeIcons']=array_merge($base['typeIcons'],$cfg['typeIcons']);
if(isset($cfg['serviceLabels'])&&is_array($cfg['serviceLabels']))$base['serviceLabels']=array_merge($base['serviceLabels'],$cfg['serviceLabels']);
if(isset($cfg['connectionStyles'])&&is_array($cfg['connectionStyles']))$base['connectionStyles']=array_merge($base['connectionStyles'],$cfg['connectionStyles']);
if(isset($cfg['vlanGroups'])&&is_array($cfg['vlanGroups']))$base['vlanGroups']=array_merge($base['vlanGroups'],$cfg['vlanGroups']);
if(isset($cfg['groupStyles'])&&is_array($cfg['groupStyles']))$base['groupStyles']=array_merge($base['groupStyles'],$cfg['groupStyles']);
if(isset($cfg['typeStyles'])&&is_array($cfg['typeStyles']))$base['typeStyles']=array_merge($base['typeStyles'],$cfg['typeStyles']);
if(isset($cfg['devices'])&&is_array($cfg['devices']))$base['devices']=array_values($cfg['devices']);
if(!isset($base['connectionStyles']['DEFAULT']['color']))$base['connectionStyles']['DEFAULT']=['color'=>'#666666'];
if(!isset($base['groupStyles']['Unbekannt'])||!is_array($base['groupStyles']['Unbekannt']))$base['groupStyles']['Unbekannt']=['fill'=>'#ffffff','stroke'=>'#d1d5db'];
return $base;
}
function nw_ip_in_cidr($ip,$cidr){
$p=explode('/',(string)$cidr);
if(count($p)!==2)return false;
$bits=(int)$p[1];
$base=ip2long($p[0]);
$val=ip2long((string)$ip);
if($base===false||$val===false||$bits<0||$bits>32)return false;
if($bits===0)return true;
$mask=$bits===32?0xFFFFFFFF:(~((1<<(32-$bits))-1))&0xFFFFFFFF;
return(($base&$mask)===($val&$mask));
}
function nw_ip_covered($ip,$vlanGroups){
foreach($vlanGroups as $k=>$label){
$k=(string)$k;
if($k==='')continue;
if(strpos($k,'/')!==false){if(nw_ip_in_cidr($ip,$k))return true;}
elseif(strpos($ip,$k)===0)return true;
}
return false;
}
function applyDevicesDerivedDefaults(&$cfg){
foreach($cfg['devices'] as $item){
if(!is_array($item))continue;
$ip=(string)($item['IP']??$item['ip']??'');
if($ip!==''){
$parts=explode('.',$ip);
if(count($parts)===4){
$valid=true;
for($i=0;$i<4;$i++){if(!ctype_digit($parts[$i])||(int)$parts[$i]>255){$valid=false;break;}}
if($valid&&!nw_ip_covered($ip,$cfg['vlanGroups'])){
$prefix=$parts[0].'.'.$parts[1].'.'.$parts[2].'.';
if(!array_key_exists($prefix,$cfg['vlanGroups']))$cfg['vlanGroups'][$prefix]=$prefix.'0/24';
}
}
}
}
foreach($cfg['vlanGroups'] as $prefix=>$label){
if(!array_key_exists($label,$cfg['groupStyles']))$cfg['groupStyles'][$label]=['fill'=>'#f3f4f6','stroke'=>'#d1d5db'];
}
}
function load_config($path){
if(is_readable($path)){
$raw=@file_get_contents($path);
$tmp=@json_decode((string)$raw,true);
if(is_array($tmp)){$cfg=normalizeConfig($tmp);applyDevicesDerivedDefaults($cfg);return $cfg;}
}
$cfg=defaultConfig();
applyDevicesDerivedDefaults($cfg);
$dir=dirname($path);
if(!is_dir($dir))@mkdir($dir,0775,true);
if(!is_file($path)){
$json=json_encode($cfg,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
if($json!==false)@file_put_contents($path,$json,LOCK_EX);
}
return $cfg;
}
function nw_b32_encode($bin){
$alpha='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
$out='';$bits=0;$val=0;
for($i=0;$i<strlen($bin);$i++){
$val=($val<<8)|ord($bin[$i]);
$bits+=8;
while($bits>=5){$bits-=5;$out.=$alpha[($val>>$bits)&31];}
}
if($bits>0)$out.=$alpha[($val<<(5-$bits))&31];
return $out;
}
function nw_b32_decode($s){
$alpha='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
$s=strtoupper(preg_replace('/[^A-Za-z2-7]/','',(string)$s));
$out='';$bits=0;$val=0;
for($i=0;$i<strlen($s);$i++){
$p=strpos($alpha,$s[$i]);
if($p===false)continue;
$val=($val<<5)|$p;
$bits+=5;
if($bits>=8){$bits-=8;$out.=chr(($val>>$bits)&255);}
}
return $out;
}
function nw_totp_code($secret,$slice){
$key=nw_b32_decode($secret);
$bin=pack('N',0).pack('N',$slice);
$hash=hash_hmac('sha1',$bin,$key,true);
$off=ord(substr($hash,-1))&0x0F;
$v=((ord($hash[$off])&0x7F)<<24)|((ord($hash[$off+1])&0xFF)<<16)|((ord($hash[$off+2])&0xFF)<<8)|(ord($hash[$off+3])&0xFF);
return str_pad((string)($v%1000000),6,'0',STR_PAD_LEFT);
}
function nw_totp_verify($secret,$code){
$code=preg_replace('/\s+/','',(string)$code);
if(!preg_match('/^\d{6}$/',$code))return false;
$slice=(int)floor(time()/30);
for($i=-1;$i<=1;$i++){
if(hash_equals(nw_totp_code($secret,$slice+$i),$code))return true;
}
return false;
}
function nw_json_for_script($data){return json_encode($data,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_UNESCAPED_UNICODE);}
function nw_totp_path($jsondir){return dirname($jsondir).DIRECTORY_SEPARATOR.'totp.secret.php';}
function nw_totp_load($path){
if(!is_readable($path))return null;
$lines=@file($path,FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES);
if(!is_array($lines))return null;
foreach($lines as $line){
$line=trim($line);
if($line===''||strpos($line,'<?php')===0)continue;
$data=json_decode($line,true);
if(is_array($data)&&isset($data['secret']))return $data;
}
return null;
}
function nw_totp_store($path,$data){
$dir=dirname($path);
if(!is_dir($dir))@mkdir($dir,0775,true);
$json=json_encode($data);
if($json===false)return false;
return @file_put_contents($path,"<?php exit; ?>\n".$json."\n",LOCK_EX)!==false;
}
function save_config($path,$cfg){
$cfg=normalizeConfig($cfg);
applyDevicesDerivedDefaults($cfg);
foreach($cfg['devices'] as &$d){
if(!is_array($d))continue;
if(isset($d['Connections'])&&is_array($d['Connections'])){
foreach($d['Connections'] as &$c){if(is_array($c))unset($c['direction']);}
unset($c);
}
}
unset($d);
$json=json_encode($cfg,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
if($json===false)return false;
$dir=dirname($path);
if(!is_dir($dir))@mkdir($dir,0775,true);
if(is_readable($path))@copy($path,$path.'.bak');
return @file_put_contents($path,$json,LOCK_EX)!==false;
}
session_start();
if(empty($_SESSION['networking_csrf']))$_SESSION['networking_csrf']=bin2hex(random_bytes(16));
$csrfToken=$_SESSION['networking_csrf'];
$totpPath=nw_totp_path($networking_jsondir);
$mfaMarkerPath=dirname($networking_jsondir).DIRECTORY_SEPARATOR.'remove_if_mfa_lost.txt';
$mfaSetupCodePath=dirname($networking_jsondir).DIRECTORY_SEPARATOR.'mfa-setup-code.php';
$mfaMarkerText="NICHT loeschen. Wird diese Datei geloescht, erzwingt die Seite ein neues MFA-Setup (Reset-Code steht dann in mfa-setup-code.php).\n";
$totp=nw_totp_load($totpPath);
if($totp===null){
$totp=['secret'=>nw_b32_encode(random_bytes(20)),'confirmed'=>false];
nw_totp_store($totpPath,$totp);
}
$setupMode='none';
if(empty($totp['confirmed']))$setupMode='first';
elseif(!is_file($mfaMarkerPath)){
if(empty($totp['pending'])||empty($totp['setup_code'])){
$totp['pending']=nw_b32_encode(random_bytes(20));
$totp['setup_code']=str_pad((string)random_int(0,99999999),8,'0',STR_PAD_LEFT);
nw_totp_store($totpPath,$totp);
@file_put_contents($mfaSetupCodePath,"<?php exit; ?>\nMFA-Reset-Code fuer das Setup: ".$totp['setup_code']."\n",LOCK_EX);
}
$setupMode='reset';
}
$save_msg='';
$save_err='';
$setup_err='';
$pendingConfig=null;
if($_SERVER['REQUEST_METHOD']==='POST'&&($_POST['action']??'')==='totp_confirm'){
$token=$_POST['csrf']??'';
if(!hash_equals($csrfToken,(string)$token))$setup_err='Ungültiges Sicherheits-Token.';
elseif($setupMode==='first'){
if(nw_totp_verify((string)$totp['secret'],(string)($_POST['totp']??''))){
$totp['confirmed']=true;
nw_totp_store($totpPath,$totp);
@file_put_contents($mfaMarkerPath,$mfaMarkerText,LOCK_EX);
$setupMode='none';
$save_msg='MFA eingerichtet.';
}else $setup_err='Code ungültig.';
}
elseif($setupMode==='reset'){
$sc=preg_replace('/\s+/','',(string)($_POST['setup_code']??''));
if(!hash_equals((string)$totp['setup_code'],$sc))$setup_err='Reset-Code falsch (siehe mfa-setup-code.php auf dem Server).';
elseif(nw_totp_verify((string)$totp['pending'],(string)($_POST['totp']??''))){
$totp['secret']=$totp['pending'];
$totp['confirmed']=true;
unset($totp['pending'],$totp['setup_code']);
nw_totp_store($totpPath,$totp);
@unlink($mfaSetupCodePath);
@file_put_contents($mfaMarkerPath,$mfaMarkerText,LOCK_EX);
$setupMode='none';
$save_msg='MFA neu eingerichtet.';
}else $setup_err='Code ungültig.';
}
}
if($_SERVER['REQUEST_METHOD']==='POST'&&($_POST['action']??'')==='save'){
$token=$_POST['csrf']??'';
$decoded=json_decode((string)($_POST['config_json']??''),true);
if(!hash_equals($csrfToken,(string)$token)){$save_err='Sitzung abgelaufen – nicht gespeichert (Änderungen noch da, erneut speichern).';if(is_array($decoded))$pendingConfig=$decoded;}
elseif($setupMode!=='none')$save_err='Zuerst MFA-Setup abschließen.';
elseif(!nw_totp_verify((string)$totp['secret'],(string)($_POST['totp']??''))){
$save_err='TOTP-Code ungültig – nicht gespeichert (Änderungen noch da).';
if(is_array($decoded))$pendingConfig=$decoded;
}
elseif(!is_array($decoded))$save_err='Konfiguration ist kein gültiges JSON.';
else{
$curHash=is_readable($networking_jsondir)?sha1((string)@file_get_contents($networking_jsondir)):'new';
if(!hash_equals($curHash,(string)($_POST['config_hash']??''))){
$save_err='config.json wurde zwischenzeitlich geändert – nicht gespeichert (Änderungen noch da).';
$pendingConfig=$decoded;
}
elseif(save_config($networking_jsondir,$decoded))$save_msg='Gespeichert.';
else{$save_err='Fehler beim Speichern: '.$networking_jsondir;$pendingConfig=$decoded;}
}
}
$config=load_config($networking_jsondir);
$clientDirty=false;
if($pendingConfig!==null){
$config=normalizeConfig($pendingConfig);
applyDevicesDerivedDefaults($config);
$clientDirty=true;
}
$cfgFileHash=is_readable($networking_jsondir)?sha1((string)@file_get_contents($networking_jsondir)):'new';
$totpSetup=null;
if($setupMode!=='none'){
$host=(string)($_SERVER['HTTP_HOST']??'server');
$sec=$setupMode==='reset'?(string)$totp['pending']:(string)$totp['secret'];
$label=rawurlencode($networking_title.':'.$host);
$totpSetup=['secret'=>$sec,'uri'=>'otpauth://totp/'.$label.'?secret='.rawurlencode($sec).'&issuer='.rawurlencode($networking_title),'mode'=>$setupMode];
}
$configError=null;
if(!is_readable($networking_jsondir))$configError='Keine config.json gefunden – Standard geladen. Mit „+ Gerät" starten und speichern.';
header('Content-Type: text/html; charset=utf-8');
?>
<!doctype html>
<?php $__th=(isset($networking_theme)&&in_array($networking_theme,['light','dark'],true))?$networking_theme:'auto'; ?><html lang="de"<?= $__th==='light'?' data-theme="light"':($__th==='dark'?' data-theme="dark"':'') ?>>
<head>
<meta charset="utf-8">
<meta name="color-scheme" content="only light">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="icon" type="image/svg+xml" href="<?=$networking_icon?>">
<title><?=$networking_title?></title>
<style>
body{margin:0;font-family:Arial,Helvetica,sans-serif;background:var(--bg);color:var(--fg);overflow:hidden}
#appShell{display:flex;flex-direction:column;height:100vh;width:100vw}
#topBar{flex:0 0 auto;display:flex;align-items:center;gap:10px;padding:8px 12px;border-bottom:1px solid var(--border);background:var(--panel);box-shadow:0 1px 3px rgba(0,0,0,.06);min-height:36px;flex-wrap:wrap}
#topLinks{display:flex;gap:10px;font-size:12px}
#topLinks a{color:var(--muted);text-decoration:none}
#topLinks a:hover{color:var(--accent);text-decoration:underline}
button{font-family:inherit}
.btnPrimary{border-radius:6px;border:1px solid var(--accent);background:var(--accent);color:var(--accent-fg);font-size:13px;padding:7px 14px;cursor:pointer;white-space:nowrap}
.btnPrimary:hover{background:var(--accent)}
.btnPrimary.dirtyState{background:var(--warn);border-color:var(--warn)}
.btnGhost{border-radius:6px;border:1px solid var(--border);background:var(--bg);color:var(--fg);font-size:13px;padding:6px 12px;cursor:pointer;white-space:nowrap}
.btnGhost:hover{background:var(--panel);border-color:var(--border)}
.btnDanger{border-radius:6px;border:1px solid var(--danger);background:var(--bg);color:var(--danger);font-size:13px;padding:6px 12px;cursor:pointer;white-space:nowrap}
.btnDanger:hover{background:var(--danger-bg)}
.btnSmall{font-size:11px;padding:4px 8px}
.notice{position:fixed;top:96px;left:50%;transform:translateX(-50%);z-index:40;font-size:13px;padding:8px 14px;border-radius:6px;box-shadow:0 2px 8px rgba(0,0,0,.15)}
.notice.ok{background:var(--success-bg);border:1px solid var(--success);color:var(--success)}
.notice.err{background:var(--danger-bg);border:1px solid var(--danger);color:var(--danger-fg)}
#connectBanner{position:fixed;top:96px;left:50%;transform:translateX(-50%);z-index:40;display:none;align-items:center;gap:10px;font-size:13px;font-weight:bold;color:var(--warn);background:var(--warn-bg);border:1px solid var(--warn);padding:8px 14px;border-radius:6px;box-shadow:0 2px 8px rgba(0,0,0,.15)}
.modalBackdrop{position:fixed;inset:0;background:rgba(17,24,39,.55);display:none;align-items:center;justify-content:center;z-index:1000;padding:12px;box-sizing:border-box}
.modalPanel{background:var(--panel);border-radius:10px;border:1px solid var(--border);box-shadow:0 12px 40px rgba(0,0,0,.25);max-width:640px;width:100%;max-height:92vh;display:flex;flex-direction:column}
.modalHeader{display:flex;justify-content:space-between;align-items:center;padding:12px 14px;border-bottom:1px solid var(--border)}
.modalTitle{font-size:16px;font-weight:bold}
.modalBody{padding:12px 14px;overflow:auto}
.modalFooter{display:flex;justify-content:space-between;gap:8px;padding:12px 14px;border-top:1px solid var(--border)}
.formRow{display:flex;gap:10px;margin-bottom:10px}
.formCol{flex:1}
label{display:block;font-size:12px;font-weight:bold;margin-bottom:4px;color:var(--muted)}
input[type="text"],input[type="number"],textarea,select{width:100%;box-sizing:border-box;border-radius:6px;border:1px solid var(--border);font-size:13px;padding:7px 8px;font-family:inherit;background:var(--bg);color:var(--fg)}
input[type="text"]:focus,input[type="number"]:focus,textarea:focus,select:focus{border-color:var(--accent);outline:none;box-shadow:0 0 0 2px rgba(0,112,255,.15)}
textarea{min-height:64px;resize:vertical}
.typeRow{display:flex;gap:8px;align-items:center}
.typeRow .combo{flex:1}
.combo{position:relative}
.comboList{position:absolute;left:0;right:0;top:100%;margin-top:2px;z-index:60;background:var(--panel);border:1px solid var(--border);border-radius:6px;max-height:210px;overflow:auto;box-shadow:0 8px 20px rgba(0,0,0,.15);display:none}
.comboItem{display:flex;gap:8px;align-items:center;padding:6px 9px;font-size:13px;cursor:pointer;color:var(--fg)}
.comboItem:hover,.comboItem.active{background:var(--panel2)}
.comboItem img{width:18px;height:18px;border-radius:4px;flex:0 0 auto}
.comboItem .comboSub{color:var(--muted);font-size:11px;margin-left:auto}
#devTypeIcon{width:30px;height:30px;border-radius:6px;border:1px solid var(--border);background:var(--panel);flex:0 0 auto}
#connModalInfo{font-size:13px;color:var(--muted);background:var(--panel);border:1px solid var(--border);border-radius:6px;padding:8px 10px;margin-bottom:10px}
#overlayActions{display:flex;gap:6px;margin:6px 0}
#totpInput{width:76px;box-sizing:border-box;border-radius:6px;border:1px solid var(--border);font-size:13px;padding:7px 8px;text-align:center;letter-spacing:2px}
#totpInput:focus{border-color:var(--accent);outline:none;box-shadow:0 0 0 2px rgba(0,112,255,.15)}
#layerBar{flex:0 0 auto;display:flex;align-items:center;gap:12px;padding:5px 12px;background:var(--panel);border-bottom:1px solid var(--border);font-size:12px;flex-wrap:wrap}
#layerBarTitle{color:var(--muted);font-weight:bold}
.layerToggle{display:inline-flex;align-items:center;gap:4px;color:var(--muted);cursor:pointer;user-select:none}
.layerToggle input{accent-color:var(--accent)}
.layerPhys{color:var(--fg);font-weight:bold}
#ctxMenu{position:fixed;z-index:3000;background:var(--panel);border:1px solid var(--border);border-radius:8px;box-shadow:0 8px 24px rgba(0,0,0,.18);min-width:190px;padding:4px;display:none}
.ctxItem{padding:7px 10px;font-size:13px;border-radius:5px;cursor:pointer;color:var(--fg)}
.ctxItem:hover{background:var(--panel2)}
.ctxItem.danger{color:var(--danger)}
.ctxItem.danger:hover{background:var(--danger-bg)}
.ctxSep{height:1px;background:var(--border);margin:4px 6px}
.ctxTitle{padding:5px 10px;font-size:11px;font-weight:bold;color:var(--muted);text-transform:uppercase;letter-spacing:.05em}
#totpQrWrap{display:flex;justify-content:center;margin:10px 0;background:var(--panel);padding:8px}
#totpQr{image-rendering:pixelated}
.totpSecret{text-align:center;font-family:monospace;font-size:15px;font-weight:bold;letter-spacing:2px;background:var(--panel);border:1px solid var(--border);border-radius:6px;padding:8px;margin:8px 0;word-break:break-all}
.totpStep{font-size:13px;color:var(--muted);margin:6px 0}
.totpCodeInput{text-align:center;font-size:16px;letter-spacing:3px;margin:4px 0}
.totpFootHint{font-size:11px;color:var(--muted);align-self:center;max-width:60%}
.msgInline{background:var(--danger-bg);border:1px solid var(--danger);color:var(--danger-fg);font-size:12px;padding:6px 8px;border-radius:6px;margin-bottom:8px}
.jsonHint{font-size:12px;color:var(--muted);background:var(--panel);border:1px solid var(--border);border-radius:6px;padding:7px 9px}
.cableLabel{font-size:8.5px;fill:var(--fg);font-weight:bold;paint-order:stroke;stroke:var(--bg);stroke-width:3px;stroke-linejoin:round}
.viewSelect{width:auto;border-radius:6px;border:1px solid var(--border);font-size:12px;padding:4px 6px;background:var(--bg)}
.layerSep{width:1px;height:18px;background:var(--border)}
#layerBarTitle2{color:var(--muted);font-weight:bold}
#quickText{min-height:110px;font-family:monospace;font-size:12px}
#quickPreview{margin-top:8px;max-height:180px;overflow:auto;font-size:12px}
.quickRow{display:flex;gap:8px;align-items:center;padding:4px 6px;border-bottom:1px solid var(--border)}
.quickRow img{width:18px;height:18px;border-radius:4px}
.quickRow .qh{font-weight:bold;min-width:120px}
.quickRow .qi{color:var(--muted);min-width:100px}
.quickRow .qt{color:var(--accent)}
.quickRow.qskip{opacity:.5}
.quickRow .qs{color:var(--warn);font-size:11px;margin-left:auto}
#topBarTitle{font-size:15px;font-weight:bold;white-space:nowrap}
#searchWrapper{position:relative;flex:1;max-width:520px}
#searchInput{width:100%;box-sizing:border-box;border-radius:999px;border:1px solid var(--border);background:var(--panel);color:var(--fg);font-size:13px;padding:6px 28px 6px 28px;outline:none}
#searchInput:focus{border-color:var(--accent);background:var(--bg);box-shadow:0 0 0 2px rgba(0,112,255,.15)}
#searchIcon{position:absolute;left:9px;top:50%;transform:translateY(-50%);font-size:12px;color:var(--muted)}
#searchMeta{font-size:12px;color:var(--muted);white-space:nowrap}
#main{flex:1 1 auto;display:flex;min-height:0;min-width:0}
#mapArea{flex:1 1 auto;position:relative;min-width:0;min-height:0}
#mapShell{position:absolute;inset:0}
#mapSvg{width:100%;height:100%;display:block;background-color:var(--bg);background-image:radial-gradient(var(--border) 1px,transparent 1px);background-size:22px 22px;cursor:grab}
#mapSvg:active{cursor:grabbing}
.error{position:fixed;left:60px;top:60px;z-index:30;color:var(--danger);font-weight:bold;background:var(--panel);border:1px solid var(--danger);border-radius:6px;padding:8px 10px;font-size:12px;box-shadow:0 2px 8px rgba(0,0,0,.12)}
#detailOverlay{position:fixed;top:62px;right:10px;width:340px;max-height:64vh;z-index:20;background:var(--panel);border-radius:8px;border:1px solid var(--border);box-shadow:0 8px 24px rgba(0,0,0,.18);padding:8px 10px;font-size:11px;color:var(--fg);display:none;overflow:auto}
#detailOverlayHeader{display:flex;align-items:center;justify-content:space-between;margin-bottom:4px}
#detailOverlayTitle{font-weight:bold;font-size:12px}
#detailOverlaySubtitle{font-size:10px;color:var(--muted);margin-top:1px}
#detailOverlayClose{border:none;background:none;color:var(--muted);font-size:16px;cursor:pointer;padding:0 4px}
#detailBadges{display:flex;flex-wrap:wrap;gap:4px;margin:4px 0}
.badge{display:inline-flex;align-items:center;gap:4px;border-radius:3px;padding:1px 6px;font-size:10px;border:1px solid var(--border);color:var(--fg);background:var(--bg)}
.badgeDot{width:7px;height:7px;border-radius:999px;background:var(--muted)}
.sectionTitle{font-size:11px;font-weight:bold;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);margin:6px 0 4px 0}
.infoRow{display:flex;justify-content:space-between;font-size:11px;margin-bottom:3px}
.infoRow span:nth-child(1){color:var(--muted);margin-right:8px;white-space:nowrap}
.infoRow span:nth-child(2){color:var(--fg);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.noteBox{font-size:11px;color:var(--fg);background:var(--panel);border-radius:3px;border:1px solid var(--border);padding:5px 6px;margin-top:4px;white-space:pre-wrap;word-break:break-word}
.noteTitle{font-size:11px;font-weight:bold;margin-bottom:3px}
.connectionItem{border-radius:3px;border:1px solid var(--border);padding:5px 6px;margin-bottom:4px;cursor:pointer;background:var(--bg);display:flex;flex-direction:column;gap:3px}
.connectionItem:hover{background:var(--panel2)}
.connectionHeader{display:flex;align-items:center;justify-content:space-between;gap:6px}
.connectionType{font-size:11px;font-weight:bold;color:var(--fg)}
.connectionTarget{font-size:11px;color:var(--muted)}
.connectionMeta{font-size:10px;color:var(--muted)}
.connectionBadge{display:inline-flex;align-items:center;gap:4px;font-size:10px;border-radius:3px;padding:1px 5px;border:1px solid var(--border);background:var(--bg)}
.connectionColorDot{width:7px;height:7px;border-radius:999px;background:var(--muted)}
.deviceIconWrapper{width:26px;height:26px;border-radius:3px;background:var(--panel);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;overflow:hidden;margin-right:8px}
.deviceIcon{max-width:22px;max-height:22px;display:block}
#deviceHeaderRow{display:flex;align-items:center;gap:8px;margin-bottom:6px}
.deviceHostname{font-size:13px;font-weight:bold}
.deviceIp{font-size:11px;color:var(--muted)}
.deviceType{font-size:11px;color:var(--muted)}
.nodeLabel{font-size:10px;font-family:Arial,Helvetica,sans-serif;font-weight:bold;fill:var(--fg);paint-order:stroke;stroke:var(--bg);stroke-width:3px;stroke-linejoin:round}
.nodeLabelIp{font-size:8.5px;fill:var(--muted);paint-order:stroke;stroke:var(--bg);stroke-width:3px;stroke-linejoin:round}
.nodeGroupLabel{font-size:11px;font-weight:bold;fill:var(--accent-fg)}
.nodeCircle{cursor:pointer}
.nodeCircle:hover{stroke:var(--accent);stroke-width:1.6}
.groupRect{fill:var(--bg);stroke:var(--border);stroke-width:1}
@media(max-width:720px){#detailOverlay{left:8px;right:8px;width:auto;max-height:60vh}}
</style>
<style id="theme-tokens">
:root{
--bg:#ffffff;--fg:#141414;--muted:#5a5f66;--border:#d5d7dd;
--panel:#f5f6f8;--panel2:#e9ebef;--panelhead:#eef0f3;
--accent:#0a63ff;--accent-fg:#ffffff;--link:#0a58ca;
--danger:#b3261e;--danger-bg:#fde7e7;--danger-fg:#7f1512;
--success:#1a7f37;--success-bg:#e6f4ea;--warn:#8a6d00;--warn-bg:#fff4cf;
--ctrl-bg:#141414;--ctrl-fg:#ffffff;--shadow:rgba(0,0,0,.18);
}
:root[data-theme="dark"]{
--bg:#0f1113;--fg:#e8e8ea;--muted:#a6adb6;--border:#2b3038;
--panel:#17191d;--panel2:#20242a;--panelhead:#20242a;
--accent:#5b9bff;--accent-fg:#0a0d12;--link:#7db0ff;
--danger:#ff6b6b;--danger-bg:#3f1d1d;--danger-fg:#ffd9d9;
--success:#5bd47e;--success-bg:#163a22;--warn:#e6c34a;--warn-bg:#3a3212;
--ctrl-bg:#20242a;--ctrl-fg:#e8e8ea;--shadow:rgba(0,0,0,.6);
}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]):not([data-theme="dark"]){
--bg:#0f1113;--fg:#e8e8ea;--muted:#a6adb6;--border:#2b3038;
--panel:#17191d;--panel2:#20242a;--panelhead:#20242a;
--accent:#5b9bff;--accent-fg:#0a0d12;--link:#7db0ff;
--danger:#ff6b6b;--danger-bg:#3f1d1d;--danger-fg:#ffd9d9;
--success:#5bd47e;--success-bg:#163a22;--warn:#e6c34a;--warn-bg:#3a3212;
--ctrl-bg:#20242a;--ctrl-fg:#e8e8ea;--shadow:rgba(0,0,0,.6);
}}
</style>
</head>
<body>
<div id="appShell">
<div id="topBar">
<div id="topBarTitle"><?=$networking_heading?></div>
<div id="searchWrapper">
<div id="searchIcon">🔍</div>
<input id="searchInput" type="search" autocomplete="off" placeholder="Suche: Hostname, IP, Typ, VLAN, Ziel, Notiz">
</div>
<div id="searchMeta"><span id="searchCountDevices">0</span> Geräte · <span id="searchCountConns">0</span> Verbindungen</div>
<button type="button" class="btnGhost" id="btnAddDevice">+ Gerät</button>
<button type="button" class="btnGhost" id="btnQuickAdd" title="Zeilen mit Hostname/IP einfügen – Typ und Subnetz werden automatisch erkannt">⚡ Einfügen</button>
<input type="text" id="totpInput" inputmode="numeric" autocomplete="one-time-code" maxlength="6" placeholder="TOTP" title="Code aus der Authenticator-App"<?php if($totpSetup!==null)echo' disabled';?>>
<button type="button" class="btnPrimary" id="btnSave"<?php if($totpSetup!==null)echo' disabled';?>>Speichern</button>
<div id="topLinks">
<a href="?_page=bsp">Beispiel</a>
<a href="?_page=raw" target="_blank" rel="noopener noreferrer">config.json</a>
<a href="?_page=license" target="_blank" rel="noopener noreferrer">LICENSE</a>
</div>
</div>
<div id="layerBar">
<span id="layerBarTitle">Ansicht:</span>
<select id="viewModeSel" class="viewSelect">
<option value="vlan">Subnetz / VLAN</option>
<option value="category">Kategorie (Endgeräte …)</option>
<option value="kind">Art (Physisch / VM / Extern)</option>
</select>
<span class="layerSep"></span>
<span id="layerBarTitle2">Ebenen:</span>
<label class="layerToggle"><input type="checkbox" id="lyVlan" checked> Gruppen-Boxen</label>
<label class="layerToggle layerPhys"><input type="checkbox" id="lyCable" checked> Physisch (Kabel)</label>
<label class="layerToggle"><input type="checkbox" id="lySvc" checked> Dienste</label>
<label class="layerToggle"><input type="checkbox" id="lyBlocked" checked> Blockierte</label>
<label class="layerToggle"><input type="checkbox" id="lyHost" checked> Host/VM</label>
</div>
<div id="main">
<div id="mapArea">
<div id="mapShell">
<svg id="mapSvg"><g id="mapContent"></g></svg>
</div>
</div>
</div>
</div>
<?php if($configError):?><div class="error"><?php echo h($configError);?></div><?php endif;?>
<?php if($save_msg!==''):?><div class="notice ok" id="saveNotice"><?php echo h($save_msg);?></div><?php endif;?>
<?php if($save_err!==''):?><div class="notice err" id="saveNotice"><?php echo h($save_err);?></div><?php endif;?>
<div id="connectBanner">Ziel anklicken <button type="button" class="btnGhost" id="btnConnectCancel">Abbrechen</button></div>
<form id="saveForm" method="post" autocomplete="off">
<input type="hidden" name="action" value="save">
<input type="hidden" name="csrf" value="<?php echo h($csrfToken);?>">
<input type="hidden" name="totp" id="totpHidden">
<input type="hidden" name="config_hash" value="<?php echo h($cfgFileHash);?>">
<input type="hidden" name="config_json" id="config_json">
</form>
<div id="ctxMenu"></div>
<?php if($totpSetup!==null):?>
<div class="modalBackdrop" id="totpModal" style="display:flex">
<div class="modalPanel">
<div class="modalHeader">
<div class="modalTitle"><?php echo $totpSetup['mode']==='reset'?'MFA neu einrichten':'MFA einrichten';?></div>
</div>
<form method="post" autocomplete="off">
<div class="modalBody">
<?php if($setup_err!==''){echo'<div class="msgInline">'.h($setup_err).'</div>';}?>
<div class="totpStep">1. QR-Code scannen (oder Secret manuell eintragen):</div>
<div id="totpQrWrap"><canvas id="totpQr"></canvas></div>
<div class="totpSecret"><?php echo h($totpSetup['secret']);?></div>
<?php if($totpSetup['mode']==='reset'):?>
<div class="totpStep">2. Reset-Code aus der Server-Datei mfa-setup-code.php:</div>
<input type="text" name="setup_code" class="totpCodeInput" maxlength="8" inputmode="numeric" placeholder="Reset-Code" required>
<div class="totpStep">3. Code aus der App:</div>
<?php else:?>
<div class="totpStep">2. Code aus der App:</div>
<?php endif;?>
<input type="text" name="totp" class="totpCodeInput" maxlength="6" inputmode="numeric" autocomplete="one-time-code" placeholder="6-stelliger Code" required>
<input type="hidden" name="action" value="totp_confirm">
<input type="hidden" name="csrf" value="<?php echo h($csrfToken);?>">
</div>
<div class="modalFooter">
<span class="totpFootHint">App verloren? remove_if_mfa_lost.txt auf dem Server löschen → neues Setup.</span>
<button type="submit" class="btnPrimary">Weiter</button>
</div>
</form>
</div>
</div>
<?php endif;?>
<div class="modalBackdrop" id="deviceModal">
<div class="modalPanel">
<div class="modalHeader">
<div class="modalTitle" id="deviceModalTitle"></div>
<button type="button" class="btnGhost" id="btnDeviceClose">Schließen</button>
</div>
<div class="modalBody">
<div class="formRow">
<div class="formCol">
<label for="devHostname">Hostname</label>
<input type="text" id="devHostname">
</div>
<div class="formCol">
<label for="devIP">IP-Adresse</label>
<input type="text" id="devIP" placeholder="z.B. 10.0.1.10">
</div>
</div>
<div class="formRow">
<div class="formCol">
<label for="devType">Typ</label>
<div class="typeRow">
<img id="devTypeIcon" alt="" src="">
<div class="combo">
<input type="text" id="devType" autocomplete="off" placeholder="Typ suchen…">
<div class="comboList" id="devTypeOpts"></div>
</div>
</div>
</div>
<div class="formCol">
<label for="devKind">Art</label>
<select id="devKind">
<option value="Physisch">Physisch</option>
<option value="VM">VM</option>
<option value="Extern">Extern</option>
</select>
</div>
</div>
<div class="formRow">
<div class="formCol">
<label for="devRange">IP-Bereich (optional, z.B. Hypervisor mit VMs)</label>
<input type="text" id="devRange" placeholder="z.B. 10.0.2.0/24">
</div>
</div>
<div id="fwSection" style="display:none">
<div class="formRow">
<div class="formCol">
<label for="devFwPolicy">Firewall-Regel</label>
<select id="devFwPolicy">
<option value="allow">Alles erlauben</option>
<option value="block">Alles blockieren (außer Freigaben)</option>
</select>
</div>
<div class="formCol">
<label for="devFwPorts">Freigegebene Ports (Komma-getrennt)</label>
<input type="text" id="devFwPorts" placeholder="z.B. 443, 53">
</div>
</div>
</div>
<div class="jsonHint">Notizen: direkt in der config.json.</div>
</div>
<div class="modalFooter">
<button type="button" class="btnDanger" id="btnDeviceDelete">Gerät löschen</button>
<button type="button" class="btnPrimary" id="btnDeviceApply">Übernehmen</button>
</div>
</div>
</div>
<div class="modalBackdrop" id="connModal">
<div class="modalPanel">
<div class="modalHeader">
<div class="modalTitle">Verbindung erstellen</div>
<button type="button" class="btnGhost" id="btnConnClose">Schließen</button>
</div>
<div class="modalBody">
<div id="connModalInfo"></div>
<div class="formRow">
<div class="formCol">
<label for="connKind">Verbindungsart</label>
<select id="connKind">
<option value="service">Dienst (logisch)</option>
<option value="cable">Kabel (physisch)</option>
</select>
</div>
</div>
<div class="formRow" id="connServiceRow">
<div class="formCol">
<label for="connService">Dienst</label>
<div class="combo">
<input type="text" id="connService" autocomplete="off" placeholder="Dienst suchen…">
<div class="comboList" id="connServiceOpts"></div>
</div>
</div>
<div class="formCol">
<label for="connPort">Port (optional)</label>
<input type="number" id="connPort" min="1" max="65535" placeholder="443">
</div>
</div>
<div class="formRow" id="connVlanRow" style="display:none">
<div class="formCol">
<label for="connVlans">Port-VLANs (optional, z.B. 10,20 – kommt vom Switchport)</label>
<input type="text" id="connVlans" placeholder="z.B. 10,20">
</div>
</div>
</div>
<div class="modalFooter">
<button type="button" class="btnGhost" id="btnConnCancel">Abbrechen</button>
<button type="button" class="btnPrimary" id="btnConnApply">Erstellen</button>
</div>
</div>
</div>
<div class="modalBackdrop" id="quickModal">
<div class="modalPanel">
<div class="modalHeader">
<div class="modalTitle">Schnell einfügen</div>
<button type="button" class="btnGhost" id="btnQuickClose">Schließen</button>
</div>
<div class="modalBody">
<div class="jsonHint">Eine Zeile pro Gerät: <b>Hostname IP [Typ]</b> – den Rest erkennt die Seite.</div>
<div class="formRow" style="margin-top:10px">
<div class="formCol">
<textarea id="quickText" placeholder="fw01 10.0.1.1&#10;sw01 10.0.1.2&#10;esx01 10.0.2.5 vmware&#10;pc-buero1 10.0.3.21&#10;drucker-eg 10.0.3.40"></textarea>
</div>
</div>
<div id="quickPreview"></div>
</div>
<div class="modalFooter">
<button type="button" class="btnGhost" id="btnQuickCancel">Abbrechen</button>
<button type="button" class="btnPrimary" id="btnQuickApply">Geräte hinzufügen</button>
</div>
</div>
</div>
<div id="detailOverlay">
<div id="detailOverlayHeader">
<div>
<div id="detailOverlayTitle"></div>
<div id="detailOverlaySubtitle"></div>
</div>
<button id="detailOverlayClose" type="button">×</button>
</div>
<div id="detailBadges"></div>
<div id="detailOverlayBody"></div>
</div>
<script>
const appConfig=<?php echo nw_json_for_script($config);?>;
const iconBase=<?php echo nw_json_for_script($networking_iconbase);?>;
const initialDirty=<?php echo $clientDirty?'true':'false';?>;
const totpSetup=<?php echo $totpSetup!==null?nw_json_for_script($totpSetup):'null';?>;
let __demo=false;
try{
const dRaw=sessionStorage.getItem('networking_demo');
if(dRaw!==null){
sessionStorage.removeItem('networking_demo');
const dc=JSON.parse(dRaw);
if(dc&&typeof dc==='object'&&Array.isArray(dc.devices)){
appConfig.devices=dc.devices;
for(const k of['vlanGroups','typeIcons','typeStyles','connectionStyles']){
if(dc[k]&&typeof dc[k]==='object')appConfig[k]=dc[k];
}
for(const k of['groupStyles','serviceLabels']){
if(dc[k]&&typeof dc[k]==='object')appConfig[k]=Object.assign({},appConfig[k]||{},dc[k]);
}
__demo=true;
}
}
}catch(e){}
const demoActive=__demo;
const deviceData=Array.isArray(appConfig.devices)?appConfig.devices:[];
appConfig.devices=deviceData;
</script>
<script>
(function(){
'use strict';
let deviceIndexByHostname={};
let deviceIndexByIp={};
let nodePositions=[];
let edges=[];
let visibleDevice=[];
let selectedDeviceIndex=null;
let mapScale=1;
let mapOffsetX=0;
let mapOffsetY=0;
let isPanning=false;
let lastPanX=0;
let lastPanY=0;
let dirty=false;
let editingIndex=null;
let connectSourceIndex=null;
let pendingConn=null;
let physAdj=[];
let hostEdges=[];
let groupBoxes=[];
const layers={vlan:true,cable:true,svc:true,blocked:true,host:true};
let viewMode='vlan';
let selectedEdgeIndex=null;
function tt(v){if(v===null||v===undefined)return'';return String(v);}
function getVlanKey(ip){
if(typeof ip!=='string')return'Unbekannt';
const p=ip.split('.');
if(p.length!==4)return'Unbekannt';
for(let i=0;i<4;i++){const n=Number(p[i]);if(!Number.isInteger(n)||n<0||n>255)return'Unbekannt';}
return p[0]+'.'+p[1]+'.'+p[2]+'.0/24';
}
function ipToInt(ip){
const p=String(ip).split('.');
if(p.length!==4)return null;
let v=0;
for(let i=0;i<4;i++){const n=Number(p[i]);if(!Number.isInteger(n)||n<0||n>255)return null;v=v*256+n;}
return v;
}
function ipInCidr(ip,cidr){
const m=String(cidr).split('/');
if(m.length!==2)return false;
const bits=Number(m[1]);
const base=ipToInt(m[0]);
const val=ipToInt(ip);
if(base===null||val===null||!Number.isInteger(bits)||bits<0||bits>32)return false;
if(bits===0)return true;
const mask=bits===32?0xFFFFFFFF:(~((1<<(32-bits))-1))>>>0;
return((base&mask)>>>0)===((val&mask)>>>0);
}
function getGroupForDevice(d){
const ip=tt(d.IP||d.ip||'');
if(appConfig&&appConfig.vlanGroups){
for(const pref in appConfig.vlanGroups){
if(!Object.prototype.hasOwnProperty.call(appConfig.vlanGroups,pref))continue;
if(pref.indexOf('/')!==-1){if(ipInCidr(ip,pref))return String(appConfig.vlanGroups[pref]);}
else if(pref!==''&&ip.startsWith(pref))return String(appConfig.vlanGroups[pref]);
}
}
return getVlanKey(ip);
}
const typeCatalog={
'Firewall':{icon:'firewall.svg',color:'#d9480f'},
'Router':{icon:'router.svg',color:'#1c64d9'},
'Switch':{icon:'switch.svg',color:'#0e94d4'},
'Access Point':{icon:'wifi.svg',color:'#7c3aed'},
'Server':{icon:'server.svg',color:'#334155'},
'Windows-Server':{icon:'windows.svg',color:'#0078d4'},
'Linux-Server':{icon:'linux.svg',color:'#1f2937'},
'Domain-Controller':{icon:'ad.svg',color:'#1d4ed8'},
'DNS-Server':{icon:'dns.svg',color:'#b45309'},
'DHCP-Server':{icon:'dhcp.svg',color:'#0d9488'},
'Hypervisor':{icon:'hypervisor.svg',color:'#15803d'},
'Storage/NAS':{icon:'storage.svg',color:'#a16207'},
'Backup':{icon:'backup.svg',color:'#0f766e'},
'Datenbank':{icon:'database.svg',color:'#7e22ce'},
'Mail-Server':{icon:'mail.svg',color:'#b91c1c'},
'Web-Server':{icon:'web.svg',color:'#0284c7'},
'Proxy':{icon:'proxy.svg',color:'#4b5563'},
'VPN-Gateway':{icon:'vpn.svg',color:'#047857'},
'RDP/Terminal-Server':{icon:'rdp.svg',color:'#0369a1'},
'Monitoring':{icon:'monitoring.svg',color:'#374151'},
'Drucker':{icon:'printer.svg',color:'#475569'},
'Kamera':{icon:'camera.svg',color:'#6d28d9'},
'VoIP-Telefon':{icon:'phone.svg',color:'#0891b2'},
'USV':{icon:'ups.svg',color:'#65a30d'},
'Cloud-Dienst':{icon:'cloud.svg',color:'#2563eb'},
'IoT-Gerät':{icon:'iot.svg',color:'#9333ea'},
'PC':{icon:'pc.svg',color:'#4338ca'},
'Laptop':{icon:'laptop.svg',color:'#57534e'},
'Smartphone':{icon:'smartphone.svg',color:'#db2777'},
'Tablet':{icon:'tablet.svg',color:'#be123c'},
'Hotspot':{icon:'hotspot.svg',color:'#ea580c'},
'Internet/Provider':{icon:'internet.svg',color:'#075985'},
'Gerät (Sonstiges)':{icon:'device.svg',color:'#6b7280'}
};
const typeIconDefaults=[
{file:'firewall.svg',keys:['firewall','fortigate','fortinet','paloalto','palo-alto','sophos','pfsense','opnsense','checkpoint','watchguard','asa','fw']},
{file:'vpn.svg',keys:['vpn','ipsec']},
{file:'internet.svg',keys:['internet','provider','isp','wan','uplink','glasfaser','dsl']},
{file:'hotspot.svg',keys:['hotspot','mifi','tethering']},
{file:'smartphone.svg',keys:['smartphone','handy','iphone','android','mobil']},
{file:'tablet.svg',keys:['tablet','ipad']},
{file:'router.svg',keys:['router','mikrotik','edgerouter','fritz','tplink','tp-link','gateway','gw']},
{file:'switch.svg',keys:['switch','catalyst','procurve','nexus','cisco','sw']},
{file:'wifi.svg',keys:['wifi','wlan','accesspoint','access-point','access point','access','unifi','capwap','ap']},
{file:'hypervisor.svg',keys:['esxi','vmware','vcenter','proxmox','hyperv','hyper-v','xen','kvm','hypervisor']},
{file:'ad.svg',keys:['active-directory','activedirectory','domaincontroller','domain-controller','domain','ldap','ad','dc']},
{file:'dns.svg',keys:['dns']},
{file:'dhcp.svg',keys:['dhcp']},
{file:'mail.svg',keys:['mail','smtp','exchange','imap','pop3']},
{file:'proxy.svg',keys:['proxy']},
{file:'vpn.svg',keys:['vpn','ipsec']},
{file:'rdp.svg',keys:['rdp','terminalserver','terminal-server','terminal','ts']},
{file:'database.svg',keys:['database','datenbank','mssql','oracle','mysql','postgres','mariadb','sql','db']},
{file:'storage.svg',keys:['storage','netapp','synology','qnap','iscsi','nas','san']},
{file:'backup.svg',keys:['backup','veeam']},
{file:'monitoring.svg',keys:['monitoring','zabbix','prtg','nagios','grafana','snmp','syslog']},
{file:'printer.svg',keys:['printer','drucker','print','mfp']},
{file:'camera.svg',keys:['camera','kamera','cctv','nvr']},
{file:'phone.svg',keys:['voip','telefon','phone','pbx']},
{file:'ups.svg',keys:['usv','ups']},
{file:'cloud.svg',keys:['cloud','azure','aws']},
{file:'iot.svg',keys:['iot','sensor']},
{file:'laptop.svg',keys:['laptop','notebook']},
{file:'pc.svg',keys:['workstation','desktop','client','pc']},
{file:'web.svg',keys:['webserver','web-server','nginx','apache','iis','web','www']},
{file:'windows.svg',keys:['windows','win']},
{file:'linux.svg',keys:['linux','ubuntu','debian','centos','redhat','suse','nfs']},
{file:'server.svg',keys:['server','host','srv','vm']}
];
function getDefaultTypeIcon(type){
const low=type.toLowerCase();
const tokens=low.split(/[^a-z0-9]+/).filter(Boolean);
for(const e of typeIconDefaults){
for(const k of e.keys){
if(k.length<=3){if(tokens.indexOf(k)!==-1)return e.file;}
else if(low.indexOf(k)!==-1)return e.file;
}
}
return'device.svg';
}
function getTypeIconPath(type){
const typ=tt(type);
let file='';
if(appConfig&&appConfig.typeIcons&&appConfig.typeIcons[typ])file=String(appConfig.typeIcons[typ]);
if(file===''&&Object.prototype.hasOwnProperty.call(typeCatalog,typ))file=typeCatalog[typ].icon;
if(file===''){
if(typ==='')return'';
file=getDefaultTypeIcon(typ);
}
if(/^https?:\/\//i.test(file))return file;
return iconBase+file;
}
const categoryOrder=['Internet / Extern','Sicherheit','Netzwerk','Server & Dienste','Virtualisierung & Storage','Endgeräte','Sonstiges'];
const categoryByIcon={
'internet.svg':'Internet / Extern','cloud.svg':'Internet / Extern',
'firewall.svg':'Sicherheit','vpn.svg':'Sicherheit','proxy.svg':'Sicherheit',
'router.svg':'Netzwerk','switch.svg':'Netzwerk','wifi.svg':'Netzwerk','hotspot.svg':'Netzwerk','ups.svg':'Netzwerk',
'server.svg':'Server & Dienste','windows.svg':'Server & Dienste','linux.svg':'Server & Dienste','ad.svg':'Server & Dienste','dns.svg':'Server & Dienste','dhcp.svg':'Server & Dienste','mail.svg':'Server & Dienste','web.svg':'Server & Dienste','database.svg':'Server & Dienste','monitoring.svg':'Server & Dienste','backup.svg':'Server & Dienste','rdp.svg':'Server & Dienste',
'hypervisor.svg':'Virtualisierung & Storage','storage.svg':'Virtualisierung & Storage',
'pc.svg':'Endgeräte','laptop.svg':'Endgeräte','smartphone.svg':'Endgeräte','tablet.svg':'Endgeräte','printer.svg':'Endgeräte','camera.svg':'Endgeräte','phone.svg':'Endgeräte','iot.svg':'Endgeräte',
'device.svg':'Sonstiges'
};
const categoryColors={'Internet / Extern':'#075985','Sicherheit':'#b91c1c','Netzwerk':'#1c64d9','Server & Dienste':'#15803d','Virtualisierung & Storage':'#a16207','Endgeräte':'#7c3aed','Sonstiges':'#64748b'};
const kindGroupColors={'Physische Geräte':'#334155','VMs':'#15803d','Extern':'#64748b'};
function getCategoryForDevice(d){
const icon=getTypeIconPath(tt(d.Type||d.type||''));
const file=icon.split('/').pop();
return categoryByIcon[file]||'Sonstiges';
}
function getGroupKeyForDevice(d){
if(viewMode==='category')return getCategoryForDevice(d);
if(viewMode==='kind'){
const k=tt(d.Kind||d.kind||'');
if(k==='VM')return'VMs';
if(k==='Extern')return'Extern';
return'Physische Geräte';
}
return getGroupForDevice(d);
}
function getTypeColor(type){
const typ=tt(type);
if(appConfig&&appConfig.typeStyles&&appConfig.typeStyles[typ]&&appConfig.typeStyles[typ].color)return String(appConfig.typeStyles[typ].color);
if(Object.prototype.hasOwnProperty.call(typeCatalog,typ))return typeCatalog[typ].color;
const low=typ.toLowerCase();
if(low.indexOf('fortigate')!==-1)return'#cc6600';
if(low.indexOf('cisco')!==-1)return'#2563eb';
if(low.indexOf('esxi')!==-1||low.indexOf('hyper-v')!==-1||low.indexOf('proxmox')!==-1)return'#15803d';
if(low.indexOf('netapp')!==-1||low.indexOf('storage')!==-1)return'#b38f00';
if(low.indexOf('windows')!==-1||low.indexOf('ubuntu')!==-1||low.indexOf('linux')!==-1)return'#4b5563';
return'#6b7280';
}
function resolveServiceLabel(name){
const s=tt(name);
if(appConfig&&appConfig.serviceLabels&&appConfig.serviceLabels[s])return String(appConfig.serviceLabels[s]);
return s;
}
function getConnectionColor(connType){
const typ=tt(connType);
if(appConfig&&appConfig.connectionStyles&&appConfig.connectionStyles[typ]&&appConfig.connectionStyles[typ].color)return String(appConfig.connectionStyles[typ].color);
const low=typ.toLowerCase();
if(low==='kabel')return'#334155';
if(low.indexOf('vpn')!==-1||low.indexOf('ipsec')!==-1)return'#008000';
if(low.indexOf('rdp')!==-1)return'#cc0000';
if(low.indexOf('https')!==-1||low.indexOf('http')!==-1)return'#2563eb';
if(low.indexOf('ssh')!==-1)return'#b30059';
if(low.indexOf('dns')!==-1)return'#b38f00';
if(low.indexOf('smtp')!==-1||low.indexOf('mail')!==-1)return'#cc6600';
if(appConfig&&appConfig.connectionStyles&&appConfig.connectionStyles.DEFAULT&&appConfig.connectionStyles.DEFAULT.color)return String(appConfig.connectionStyles.DEFAULT.color);
return'#666666';
}
function buildIndexes(){
deviceIndexByHostname={};
deviceIndexByIp={};
for(let i=0;i<deviceData.length;i++){
const d=deviceData[i]||{};
const hn=tt(d.Hostname||d.hostname||'').toLowerCase();
if(hn)deviceIndexByHostname[hn]=i;
const ip=tt(d.IP||d.ip||'');
if(ip)deviceIndexByIp[ip]=i;
}
}
function resolveTargetIndex(ttg,tg){
if(!tg)return null;
const tgLow=tg.toLowerCase();
if(ttg==='hostname'&&Object.prototype.hasOwnProperty.call(deviceIndexByHostname,tgLow))return deviceIndexByHostname[tgLow];
if(ttg==='ip'&&Object.prototype.hasOwnProperty.call(deviceIndexByIp,tg))return deviceIndexByIp[tg];
if(Object.prototype.hasOwnProperty.call(deviceIndexByIp,tg))return deviceIndexByIp[tg];
if(Object.prototype.hasOwnProperty.call(deviceIndexByHostname,tgLow))return deviceIndexByHostname[tgLow];
return null;
}
const wellKnownPorts={'HTTPS':443,'HTTPS-Admin':443,'HTTP':80,'HTTP-Proxy':8080,'SSH':22,'DNS':53,'RDP':3389,'SMTP':25,'LDAP':389,'NTP':123,'SNMP':161,'SYSLOG':514,'iSCSI':3260,'NFS':2049,'MSSQL':1433,'ORACLE-DB':1521,'SMB':445,'RADIUS':1812,'CAPWAP':5246,'IPsec-VPN':500,'VPN':500,'BGP':179};
function isCableConn(c){return tt((c||{}).connType||(c||{}).service||'').toLowerCase()==='kabel';}
function isFirewallIdx(i){
const d=deviceData[i]||{};
return getTypeIconPath(d.Type||d.type||'').indexOf('firewall.svg')!==-1;
}
function connPortOf(c){
const p=Number((c||{}).port||0);
if(p>0)return p;
const k=tt((c||{}).connType||(c||{}).service||'');
if(Object.prototype.hasOwnProperty.call(wellKnownPorts,k))return wellKnownPorts[k];
return 0;
}
function fwBlocks(fw,c){
if(tt((fw||{}).FwPolicy||'')!=='block')return false;
const p=connPortOf(c);
const allow=Array.isArray((fw||{}).FwAllow)?fw.FwAllow:[];
if(p>0&&allow.indexOf(p)!==-1)return false;
return true;
}
function physPath(src,tgt){
if(src===tgt)return null;
const prev=new Array(deviceData.length).fill(-1);
const seen=new Array(deviceData.length).fill(false);
const q=[src];
seen[src]=true;
while(q.length){
const u=q.shift();
if(u===tgt)break;
const nb=physAdj[u]||[];
for(const v of nb){if(!seen[v]){seen[v]=true;prev[v]=u;q.push(v);}}
}
if(!seen[tgt])return null;
const path=[];
let cur=tgt;
while(cur!==src&&cur!==-1){path.push(cur);cur=prev[cur];}
path.push(src);
path.reverse();
return path;
}
function checkFirewall(srcIdx,tgtIdx,c){
const path=physPath(srcIdx,tgtIdx);
if(!path)return null;
let firstFw=null;
for(let k=1;k<path.length-1;k++){
const idx=path[k];
if(!isFirewallIdx(idx))continue;
if(firstFw===null)firstFw=idx;
if(fwBlocks(deviceData[idx],c))return{blocked:true,fwIndex:idx};
}
if(firstFw!==null)return{blocked:false,fwIndex:firstFw};
return null;
}
function buildLayout(){
const groups={};
for(let i=0;i<deviceData.length;i++){
const d=deviceData[i]||{};
const g=getGroupKeyForDevice(d);
if(!groups[g])groups[g]=[];
groups[g].push(i);
}
const groupKeys=Object.keys(groups);
if(viewMode==='category')groupKeys.sort((a,b)=>categoryOrder.indexOf(a)-categoryOrder.indexOf(b));
else if(viewMode==='kind'){
const ko=['Physische Geräte','VMs','Extern'];
groupKeys.sort((a,b)=>ko.indexOf(a)-ko.indexOf(b));
}
else groupKeys.sort((a,b)=>{if(a==='Unbekannt')return 1;if(b==='Unbekannt')return-1;return a.localeCompare(b,undefined,{numeric:true});});
for(const g of groupKeys){
groups[g].sort(function(a,b){
const da=deviceData[a]||{};
const db=deviceData[b]||{};
const ta=tt(da.Type||da.type||'');
const tb=tt(db.Type||db.type||'');
if(ta!==tb)return ta.localeCompare(tb);
const ha=tt(da.Hostname||da.hostname||da.IP||da.ip||'');
const hb=tt(db.Hostname||db.hostname||db.IP||db.ip||'');
return ha.localeCompare(hb,undefined,{numeric:true});
});
}
const svg=document.getElementById('mapSvg');
const parent=svg.parentElement;
const w=svg.clientWidth||parent.clientWidth||1200;
const cellW=112;
const cellH=88;
const boxPad=16;
const headerH=24;
const boxGap=46;
nodePositions=new Array(deviceData.length);
groupBoxes=[];
let cursorX=boxGap;
let cursorY=64;
let rowMaxH=0;
for(let gi=0;gi<groupKeys.length;gi++){
const g=groupKeys[gi];
const indices=groups[g];
const count=indices.length;
const cols=Math.max(Math.ceil(Math.sqrt(count)),1);
const rows=Math.max(Math.ceil(count/cols),1);
let bw=cols*cellW+boxPad*2;
const labelWidth=g.length*6.8+22;
if(bw<labelWidth)bw=labelWidth;
if(bw<110)bw=110;
const bh=rows*cellH+boxPad+headerH+8;
if(cursorX+bw>w-boxGap&&cursorX>boxGap){
cursorX=boxGap;
cursorY+=rowMaxH+boxGap;
rowMaxH=0;
}
const box={key:g,x:cursorX,y:cursorY,w:bw,h:bh};
groupBoxes.push(box);
for(let k=0;k<indices.length;k++){
const di=indices[k];
const col=k%cols;
const row=Math.floor(k/cols);
const x=box.x+boxPad+cellW*col+cellW/2;
const y=box.y+headerH+boxPad/2+cellH*row+cellH/2-14;
nodePositions[di]={x:x,y:y,group:g};
}
cursorX+=bw+boxGap;
if(bh>rowMaxH)rowMaxH=bh;
}
edges=[];
physAdj=new Array(deviceData.length);
for(let i=0;i<deviceData.length;i++)physAdj[i]=[];
for(let i=0;i<deviceData.length;i++){
const d=deviceData[i]||{};
const conns=Array.isArray(d.Connections)?d.Connections:[];
for(let ci=0;ci<conns.length;ci++){
const c=conns[ci]||{};
const ttg=tt(c.targetType||'');
const tg=tt(c.target||'');
const ct=tt(c.connType||c.service||'Unbekannt');
const tgtIndex=resolveTargetIndex(ttg,tg);
if(tgtIndex!==null&&nodePositions[i]&&nodePositions[tgtIndex]){
const cable=isCableConn(c);
edges.push({src:i,tgt:tgtIndex,connIndex:ci,connType:ct,cable:cable,blocked:false,blockedBy:null});
if(cable){physAdj[i].push(tgtIndex);physAdj[tgtIndex].push(i);}
}
}
}
hostEdges=[];
for(let hIdx=0;hIdx<deviceData.length;hIdx++){
const hd=deviceData[hIdx]||{};
const range=tt(hd.IPRange||'');
if(range.indexOf('/')===-1)continue;
for(let v=0;v<deviceData.length;v++){
if(v===hIdx)continue;
const vd=deviceData[v]||{};
const vip=tt(vd.IP||vd.ip||'');
if(vip!==''&&ipInCidr(vip,range))hostEdges.push({host:hIdx,vm:v});
}
}
for(const he of hostEdges){
physAdj[he.host].push(he.vm);
physAdj[he.vm].push(he.host);
}
for(const e of edges){
if(e.cable)continue;
const d=deviceData[e.src]||{};
const conns=Array.isArray(d.Connections)?d.Connections:[];
const res=checkFirewall(e.src,e.tgt,conns[e.connIndex]||{});
if(res&&res.blocked){e.blocked=true;e.blockedBy=res.fwIndex;}
}
renderMap();
}
function renderMap(){
const svg=document.getElementById('mapSvg');
const content=document.getElementById('mapContent');
while(content.firstChild)content.removeChild(content.firstChild);
const parent=svg.parentElement;
const w=svg.clientWidth||parent.clientWidth||1200;
const h=svg.clientHeight||parent.clientHeight||700;
svg.setAttribute('width',w);
svg.setAttribute('height',h);
const rectLayer=document.createElementNS('http://www.w3.org/2000/svg','g');
const groupLabelLayer=document.createElementNS('http://www.w3.org/2000/svg','g');
const hostLayer=document.createElementNS('http://www.w3.org/2000/svg','g');
const edgesLayer=document.createElementNS('http://www.w3.org/2000/svg','g');
const nodesLayer=document.createElementNS('http://www.w3.org/2000/svg','g');
const defs=document.createElementNS('http://www.w3.org/2000/svg','defs');
content.appendChild(defs);
const hasSel=selectedDeviceIndex!==null||selectedEdgeIndex!==null;
function isRelatedEdge(ei){
if(selectedDeviceIndex!==null){
const e=edges[ei];
return!!e&&(e.src===selectedDeviceIndex||e.tgt===selectedDeviceIndex);
}
if(selectedEdgeIndex!==null)return ei===selectedEdgeIndex;
return true;
}
function isRelatedNode(i){
if(selectedDeviceIndex!==null){
if(i===selectedDeviceIndex)return true;
for(const e of edges){
if(e.src===selectedDeviceIndex&&e.tgt===i)return true;
if(e.tgt===selectedDeviceIndex&&e.src===i)return true;
}
for(const he of hostEdges){
if(he.host===selectedDeviceIndex&&he.vm===i)return true;
if(he.vm===selectedDeviceIndex&&he.host===i)return true;
}
return false;
}
if(selectedEdgeIndex!==null){
const e=edges[selectedEdgeIndex];
return!!e&&(e.src===i||e.tgt===i);
}
return true;
}
const markerIds={};
function markerFor(color){
if(markerIds[color])return markerIds[color];
const id='arrow-'+Object.keys(markerIds).length;
const marker=document.createElementNS('http://www.w3.org/2000/svg','marker');
marker.setAttribute('id',id);
marker.setAttribute('markerWidth','7');
marker.setAttribute('markerHeight','7');
marker.setAttribute('refX','5.5');
marker.setAttribute('refY','3');
marker.setAttribute('orient','auto-start-reverse');
marker.setAttribute('markerUnits','userSpaceOnUse');
const mp=document.createElementNS('http://www.w3.org/2000/svg','path');
mp.setAttribute('d','M0 0 L6 3 L0 6 Z');
mp.setAttribute('fill',color);
marker.appendChild(mp);
defs.appendChild(marker);
markerIds[color]=id;
return id;
}
content.appendChild(rectLayer);
content.appendChild(hostLayer);
content.appendChild(edgesLayer);
content.appendChild(nodesLayer);
content.appendChild(groupLabelLayer);
if(layers.vlan){
for(const box of groupBoxes){
let anyVisible=false;
for(let i=0;i<nodePositions.length;i++){
if(!nodePositions[i]||!visibleDevice[i])continue;
if(nodePositions[i].group===box.key){anyVisible=true;break;}
}
if(!anyVisible)continue;
const gKey=box.key;
let gFill='#ffffff';
let gStroke='#cbd5e1';
if(viewMode==='category')gStroke=categoryColors[gKey]||'#94a3b8';
else if(viewMode==='kind')gStroke=kindGroupColors[gKey]||'#94a3b8';
else if(appConfig&&appConfig.groupStyles&&appConfig.groupStyles[gKey]){
const st=appConfig.groupStyles[gKey];
if(st.fill)gFill=String(st.fill);
if(st.stroke)gStroke=String(st.stroke);
}
const rect=document.createElementNS('http://www.w3.org/2000/svg','rect');
rect.setAttribute('x',String(box.x));
rect.setAttribute('y',String(box.y));
rect.setAttribute('width',String(box.w));
rect.setAttribute('height',String(box.h));
rect.setAttribute('rx','10');
rect.setAttribute('class','groupRect');
rect.setAttribute('fill',gFill);
rect.setAttribute('fill-opacity','0.75');
rect.setAttribute('stroke',gStroke);
rectLayer.appendChild(rect);
const band=document.createElementNS('http://www.w3.org/2000/svg','rect');
band.setAttribute('x',String(box.x));
band.setAttribute('y',String(box.y));
band.setAttribute('width',String(box.w));
band.setAttribute('height','22');
band.setAttribute('rx','10');
band.setAttribute('fill',gStroke==='#d1d5db'?'#94a3b8':gStroke);
rectLayer.appendChild(band);
const bandFix=document.createElementNS('http://www.w3.org/2000/svg','rect');
bandFix.setAttribute('x',String(box.x));
bandFix.setAttribute('y',String(box.y+12));
bandFix.setAttribute('width',String(box.w));
bandFix.setAttribute('height','10');
bandFix.setAttribute('fill',gStroke==='#d1d5db'?'#94a3b8':gStroke);
rectLayer.appendChild(bandFix);
const gl=document.createElementNS('http://www.w3.org/2000/svg','text');
gl.setAttribute('x',String(box.x+9));
gl.setAttribute('y',String(box.y+15));
gl.setAttribute('text-anchor','start');
gl.setAttribute('class','nodeGroupLabel');
gl.textContent=gKey;
groupLabelLayer.appendChild(gl);
}
}
if(layers.host)for(const he of hostEdges){
if(!visibleDevice[he.host]||!visibleDevice[he.vm])continue;
const p1=nodePositions[he.host];
const p2=nodePositions[he.vm];
if(!p1||!p2)continue;
const hl=document.createElementNS('http://www.w3.org/2000/svg','line');
hl.setAttribute('x1',String(p1.x));
hl.setAttribute('y1',String(p1.y));
hl.setAttribute('x2',String(p2.x));
hl.setAttribute('y2',String(p2.y));
hl.setAttribute('stroke','#94a3b8');
hl.setAttribute('stroke-width','1');
hl.setAttribute('stroke-dasharray','3 3');
hl.setAttribute('stroke-opacity',hasSel&&!(isRelatedNode(he.host)&&isRelatedNode(he.vm))?'0.08':'0.7');
hl.style.pointerEvents='none';
hostLayer.appendChild(hl);
}
function segRectHit(x1,y1,x2,y2,box,pad){
for(let t=0.06;t<0.95;t+=0.05){
const px=x1+(x2-x1)*t;
const py=y1+(y2-y1)*t;
if(px>box.x-pad&&px<box.x+box.w+pad&&py>box.y-pad&&py<box.y+box.h+pad)return true;
}
return false;
}
function edgeVisible(e){
if(e.cable&&!layers.cable)return false;
if(!e.cable&&!layers.svc)return false;
if(e.blocked&&!layers.blocked)return false;
if(!visibleDevice[e.src]||!visibleDevice[e.tgt])return false;
return true;
}
const pairMap={};
for(let i=0;i<edges.length;i++){
const e=edges[i];
if(!edgeVisible(e))continue;
const key=Math.min(e.src,e.tgt)+'_'+Math.max(e.src,e.tgt);
if(!pairMap[key])pairMap[key]=[];
pairMap[key].push(i);
}
for(let ei=0;ei<edges.length;ei++){
const e=edges[ei];
if(!edgeVisible(e))continue;
const s=e.src;
const tIdx=e.tgt;
const p1=nodePositions[s];
const p2=nodePositions[tIdx];
if(!p1||!p2)continue;
const pairKey=Math.min(s,tIdx)+'_'+Math.max(s,tIdx);
const group=pairMap[pairKey]||[ei];
const count=group.length;
let x1=p1.x;
let y1=p1.y;
let x2=p2.x;
let y2=p2.y;
let dx=x2-x1;
let dy=y2-y1;
if(dx===0&&dy===0){dy=1;}
const len=Math.sqrt(dx*dx+dy*dy)||1;
const nx=-dy/len;
const ny=dx/len;
let offset=0;
if(count>1){
const idx=group.indexOf(ei);
if(idx!==-1){
const step=26;
offset=(idx-(count-1)/2)*step;
if(s>tIdx)offset=-offset;
}
}
let avoid=0;
for(const box of groupBoxes){
if(box.key===p1.group||box.key===p2.group)continue;
if(!segRectHit(x1,y1,x2,y2,box,6))continue;
const bcx=box.x+box.w/2;
const bcy=box.y+box.h/2;
const side=dx*(bcy-y1)-dy*(bcx-x1);
const need=Math.min(box.w,box.h)+88;
const a=side>0?-need:need;
if(Math.abs(a)>Math.abs(avoid))avoid=a;
}
offset+=avoid;
const mx=(x1+x2)/2;
const my=(y1+y2)/2;
const cx=mx+nx*offset;
const cy=my+ny*offset;
const gap=20;
let d1x=cx-x1,d1y=cy-y1;
let l1=Math.sqrt(d1x*d1x+d1y*d1y)||1;
x1=x1+d1x/l1*gap;
y1=y1+d1y/l1*gap;
let d2x=cx-x2,d2y=cy-y2;
let l2=Math.sqrt(d2x*d2x+d2y*d2y)||1;
x2=x2+d2x/l2*gap;
y2=y2+d2y/l2*gap;
const dStr='M '+x1+' '+y1+' Q '+cx+' '+cy+' '+x2+' '+y2;
const hit=document.createElementNS('http://www.w3.org/2000/svg','path');
hit.setAttribute('d',dStr);
hit.setAttribute('stroke','transparent');
hit.setAttribute('stroke-width','14');
hit.setAttribute('fill','none');
hit.setAttribute('stroke-opacity','0');
hit.dataset.edgeIndex=String(ei);
hit.style.cursor='pointer';
hit.addEventListener('click',function(ev){ev.stopPropagation();selectConnectionByEdge(ei);});
hit.addEventListener('contextmenu',function(ev){ev.preventDefault();ev.stopPropagation();showEdgeMenu(ev,ei);});
edgesLayer.appendChild(hit);
const path=document.createElementNS('http://www.w3.org/2000/svg','path');
path.setAttribute('d',dStr);
let edgeColor=getConnectionColor(e.connType);
if(e.blocked)edgeColor='#9ca3af';
path.setAttribute('stroke',edgeColor);
path.setAttribute('fill','none');
path.style.pointerEvents='none';
const related=isRelatedEdge(ei);
const dimmed=hasSel&&!related;
const boosted=hasSel&&related;
if(e.cable){
path.setAttribute('stroke-width',boosted?'3.4':'2.6');
path.setAttribute('stroke-opacity',dimmed?'0.12':'0.95');
}else{
path.setAttribute('stroke-width',boosted?'2.4':'1.4');
path.setAttribute('stroke-opacity',dimmed?'0.1':(e.blocked?'0.8':'0.9'));
if(e.blocked)path.setAttribute('stroke-dasharray','5 4');
if(!dimmed)path.setAttribute('marker-end','url(#'+markerFor(edgeColor)+')');
}
edgesLayer.appendChild(path);
if(e.cable){
const srcDev=deviceData[s]||{};
const srcConns=Array.isArray(srcDev.Connections)?srcDev.Connections:[];
const vl=tt((srcConns[e.connIndex]||{}).vlans||'');
if(vl!==''){
const lx=0.25*x1+0.5*cx+0.25*x2;
const ly=0.25*y1+0.5*cy+0.25*y2;
const vt=document.createElementNS('http://www.w3.org/2000/svg','text');
vt.setAttribute('x',String(lx));
vt.setAttribute('y',String(ly-4));
vt.setAttribute('text-anchor','middle');
vt.setAttribute('class','cableLabel');
if(dimmed)vt.setAttribute('opacity','0.12');
vt.textContent='VLAN '+vl;
edgesLayer.appendChild(vt);
}
}
}
for(let i=0;i<deviceData.length;i++){
if(!visibleDevice[i])continue;
const d=deviceData[i]||{};
const pos=nodePositions[i];
if(!pos)continue;
const g=document.createElementNS('http://www.w3.org/2000/svg','g');
g.setAttribute('data-index',String(i));
if(hasSel&&!isRelatedNode(i))g.setAttribute('opacity','0.22');
const nodeColor=getTypeColor(d.Type||d.type||'');
if(selectedDeviceIndex===i){
const halo=document.createElementNS('http://www.w3.org/2000/svg','circle');
halo.setAttribute('cx',String(pos.x));
halo.setAttribute('cy',String(pos.y));
halo.setAttribute('r','23');
halo.setAttribute('fill',nodeColor);
halo.setAttribute('fill-opacity','0.16');
halo.setAttribute('stroke',nodeColor);
halo.setAttribute('stroke-opacity','0.45');
halo.setAttribute('stroke-width','1');
g.appendChild(halo);
}
const r=document.createElementNS('http://www.w3.org/2000/svg','circle');
r.setAttribute('cx',String(pos.x));
r.setAttribute('cy',String(pos.y));
r.setAttribute('r','16');
r.setAttribute('fill',selectedDeviceIndex===i?'#ffffff':'#f9fafb');
r.setAttribute('stroke',nodeColor);
r.setAttribute('stroke-width',selectedDeviceIndex===i?'2.6':'1.2');
const kind=tt(d.Kind||d.kind||'');
if(kind==='VM')r.setAttribute('stroke-dasharray','4 2');
else if(kind==='Extern')r.setAttribute('stroke-dasharray','2 2');
r.setAttribute('class','nodeCircle');
g.appendChild(r);
const iconHref=getTypeIconPath(d.Type||d.type||'');
if(iconHref){
const img=document.createElementNS('http://www.w3.org/2000/svg','image');
img.setAttribute('href',iconHref);
img.setAttribute('x',String(pos.x-10));
img.setAttribute('y',String(pos.y-10));
img.setAttribute('width','20');
img.setAttribute('height','20');
img.addEventListener('error',function(){img.remove();});
g.appendChild(img);
}
const hn=tt(d.Hostname||d.hostname||'');
const ip=tt(d.IP||d.ip||'');
const label=document.createElementNS('http://www.w3.org/2000/svg','text');
label.setAttribute('x',String(pos.x));
label.setAttribute('y',String(pos.y+24));
label.setAttribute('text-anchor','middle');
label.setAttribute('class','nodeLabel');
label.textContent=hn;
g.appendChild(label);
const labelIp=document.createElementNS('http://www.w3.org/2000/svg','text');
labelIp.setAttribute('x',String(pos.x));
labelIp.setAttribute('y',String(pos.y+34));
labelIp.setAttribute('text-anchor','middle');
labelIp.setAttribute('class','nodeLabelIp');
labelIp.textContent=ip;
g.appendChild(labelIp);
g.addEventListener('click',function(ev){ev.stopPropagation();handleNodeClick(i);});
g.addEventListener('contextmenu',function(ev){ev.preventDefault();ev.stopPropagation();showNodeMenu(ev,i);});
nodesLayer.appendChild(g);
}
updateMapTransform();
}
function updateMapTransform(){
const content=document.getElementById('mapContent');
content.setAttribute('transform','translate('+mapOffsetX+','+mapOffsetY+') scale('+mapScale+')');
}
function applyFilterFromSearch(){
const input=document.getElementById('searchInput');
const value=(input.value||'').toLowerCase().trim();
visibleDevice=new Array(deviceData.length);
let devCount=0;
let connCount=0;
let terms=[];
if(value)terms=value.split(/\s+/).filter(Boolean);
for(let i=0;i<deviceData.length;i++){
const d=deviceData[i]||{};
let vis=true;
if(terms.length>0){
let hay='';
const hn=tt(d.Hostname||d.hostname||'');
const ip=tt(d.IP||d.ip||'');
const type=tt(d.Type||d.type||'');
const kindHay=tt(d.Kind||d.kind||'');
const rangeHay=tt(d.IPRange||'');
const vlan=getVlanKey(ip);
const catHay=getCategoryForDevice(d);
hay=(hn+' '+ip+' '+type+' '+kindHay+' '+rangeHay+' '+vlan+' '+catHay).toLowerCase();
const devNotes=tt(d.Notes||d.notes||'');
if(devNotes)hay+=' '+devNotes.toLowerCase();
const conns=Array.isArray(d.Connections)?d.Connections:[];
for(const c of conns){
const ct=tt(c.connType||c.service||'');
const tgt=tt(c.target||'');
hay+=' '+ct.toLowerCase()+' '+tgt.toLowerCase();
const connNotes=tt(c.Notes||c.notes||'');
if(connNotes)hay+=' '+connNotes.toLowerCase();
}
for(const tTerm of terms){
if(hay.indexOf(tTerm)===-1){vis=false;break;}
}
}
visibleDevice[i]=vis;
if(vis){
devCount++;
const conns=Array.isArray(d.Connections)?d.Connections:[];
connCount+=conns.length;
}
}
document.getElementById('searchCountDevices').textContent=String(devCount);
document.getElementById('searchCountConns').textContent=String(connCount);
}
function renderDeviceOverlay(deviceIndex){
const d=deviceData[deviceIndex]||{};
const overlay=document.getElementById('detailOverlay');
const title=document.getElementById('detailOverlayTitle');
const subtitle=document.getElementById('detailOverlaySubtitle');
const badges=document.getElementById('detailBadges');
const body=document.getElementById('detailOverlayBody');
const hnName=tt(d.Hostname||d.hostname||'Unbekannt');
const ip=tt(d.IP||d.ip||'0.0.0.0');
title.textContent=hnName;
subtitle.textContent='Gerät · IP '+ip;
badges.innerHTML='';
const vlanBadge=document.createElement('div');
vlanBadge.className='badge';
const dot1=document.createElement('div');
dot1.className='badgeDot';
vlanBadge.appendChild(dot1);
const lbl1=document.createElement('span');
lbl1.textContent=getVlanKey(ip);
vlanBadge.appendChild(lbl1);
badges.appendChild(vlanBadge);
const conns=Array.isArray(d.Connections)?d.Connections:[];
const connBadge=document.createElement('div');
connBadge.className='badge';
const dot2=document.createElement('div');
dot2.className='badgeDot';
dot2.style.backgroundColor=conns.length>0?'#15803d':'#6b7280';
connBadge.appendChild(dot2);
const lbl2=document.createElement('span');
lbl2.textContent=conns.length+' Verbindungen';
connBadge.appendChild(lbl2);
badges.appendChild(connBadge);
const group=getGroupForDevice(d);
const groupBadge=document.createElement('div');
groupBadge.className='badge';
const dot3=document.createElement('div');
dot3.className='badgeDot';
dot3.style.backgroundColor='#2563eb';
groupBadge.appendChild(dot3);
const lbl3=document.createElement('span');
lbl3.textContent=group;
groupBadge.appendChild(lbl3);
badges.appendChild(groupBadge);
body.innerHTML='';
const header=document.createElement('div');
header.id='deviceHeaderRow';
const iconHref=getTypeIconPath(d.Type||d.type||'');
if(iconHref){
const iconWrapper=document.createElement('div');
iconWrapper.className='deviceIconWrapper';
const img=document.createElement('img');
img.className='deviceIcon';
img.alt=tt(d.Type||d.type||'');
img.src=iconHref;
img.addEventListener('error',function(){iconWrapper.remove();});
iconWrapper.appendChild(img);
header.appendChild(iconWrapper);
}
const tWrap=document.createElement('div');
const hnEl=document.createElement('div');
hnEl.className='deviceHostname';
hnEl.textContent=hnName;
const ipEl=document.createElement('div');
ipEl.className='deviceIp';
ipEl.textContent=ip;
const typeEl=document.createElement('div');
typeEl.className='deviceType';
typeEl.textContent=tt(d.Type||d.type||'');
tWrap.appendChild(hnEl);
tWrap.appendChild(ipEl);
tWrap.appendChild(typeEl);
header.appendChild(tWrap);
body.appendChild(header);
const actions=document.createElement('div');
actions.id='overlayActions';
function mkActBtn(label,cls,fn){
const b=document.createElement('button');
b.type='button';
b.className=cls+' btnSmall';
b.textContent=label;
b.addEventListener('click',fn);
actions.appendChild(b);
}
mkActBtn('Bearbeiten','btnGhost',function(){openDeviceModal(deviceIndex);});
mkActBtn('Dienst','btnGhost',function(){startConnectMode(deviceIndex,'service');});
mkActBtn('Kabel','btnGhost',function(){startConnectMode(deviceIndex,'cable');});
mkActBtn('Löschen','btnDanger',function(){deleteDevice(deviceIndex);});
body.appendChild(actions);
const stInfo=document.createElement('div');
stInfo.className='sectionTitle';
stInfo.textContent='Geräteinformationen';
body.appendChild(stInfo);
const info=document.createElement('div');
function addRow(l,v){
const row=document.createElement('div');
row.className='infoRow';
const sl=document.createElement('span');
sl.textContent=l;
const sv=document.createElement('span');
sv.textContent=v;
row.appendChild(sl);
row.appendChild(sv);
info.appendChild(row);
}
addRow('Hostname',hnName);
addRow('IP-Adresse',ip);
addRow('Typ',tt(d.Type||d.type||''));
const kindRow=tt(d.Kind||d.kind||'');
if(kindRow!=='')addRow('Art',kindRow);
addRow('Kategorie',getCategoryForDevice(d));
const rangeRow=tt(d.IPRange||'');
if(rangeRow!=='')addRow('IP-Bereich',rangeRow);
for(const he of hostEdges){
if(he.vm===deviceIndex){
const hd=deviceData[he.host]||{};
addRow('Host',tt(hd.Hostname||hd.hostname||hd.IP||hd.ip||'?'));
break;
}
}
if(isFirewallIdx(deviceIndex)){
const pol=tt(d.FwPolicy||'');
addRow('Firewall-Regel',pol==='block'?'Alles blockieren (außer Freigaben)':'Alles erlauben');
if(pol==='block'){
const allow=Array.isArray(d.FwAllow)?d.FwAllow:[];
addRow('Freigaben',allow.length>0?allow.join(', '):'keine');
}
}
addRow('VLAN / Netz',getVlanKey(ip));
addRow('Gruppe',group);
body.appendChild(info);
const devNotes=tt(d.Notes||d.notes||'').trim();
if(devNotes!==''){
const nb=document.createElement('div');
nb.className='noteBox';
const nt=document.createElement('div');
nt.className='noteTitle';
nt.textContent='Notizen';
const nc=document.createElement('div');
nc.textContent=devNotes;
nb.appendChild(nt);
nb.appendChild(nc);
body.appendChild(nb);
}
const incomingConns=[];
for(let sIndex=0;sIndex<deviceData.length;sIndex++){
if(sIndex===deviceIndex)continue;
const sd=deviceData[sIndex]||{};
const sh=tt(sd.Hostname||sd.hostname||'');
const sConns=Array.isArray(sd.Connections)?sd.Connections:[];
for(let ci=0;ci<sConns.length;ci++){
const c2=sConns[ci]||{};
if(resolveTargetIndex(tt(c2.targetType||''),tt(c2.target||''))===deviceIndex)incomingConns.push({sourceIndex:sIndex,connIndex:ci,conn:c2,sourceHostname:sh});
}
}
if(conns.length>0){
const stConn=document.createElement('div');
stConn.className='sectionTitle';
stConn.textContent='Verbindungen';
body.appendChild(stConn);
for(let i=0;i<conns.length;i++){
const c=conns[i]||{};
const item=document.createElement('div');
item.className='connectionItem';
const head=document.createElement('div');
head.className='connectionHeader';
const left=document.createElement('div');
const connType=tt(c.connType||c.service||'Unbekannt');
const typeLbl=document.createElement('div');
typeLbl.className='connectionType';
typeLbl.textContent=resolveServiceLabel(connType);
const tgtType=tt(c.targetType||'');
const tgt=tt(c.target||'');
const tgtEl=document.createElement('div');
tgtEl.className='connectionTarget';
if(tgt){
if(resolveTargetIndex(tgtType,tgt)!==null)tgtEl.textContent=tgt+' · Zielgerät vorhanden';
else tgtEl.textContent=tgt;
}else tgtEl.textContent='Ziel unbekannt';
left.appendChild(typeLbl);
left.appendChild(tgtEl);
const right=document.createElement('div');
const badge=document.createElement('div');
badge.className='connectionBadge';
const dot=document.createElement('div');
dot.className='connectionColorDot';
dot.style.backgroundColor=getConnectionColor(connType);
badge.appendChild(dot);
const portB=Number(c.port||0);
if(portB>0){
const pb=document.createElement('span');
pb.textContent='Port '+portB;
badge.appendChild(pb);
}
right.appendChild(badge);
head.appendChild(left);
head.appendChild(right);
item.appendChild(head);
const meta=document.createElement('div');
meta.className='connectionMeta';
const parts=[];
parts.push('Typ: '+connType);
const portNum=Number(c.port||0);
if(portNum>0)parts.push('Port: '+portNum);
if(tgtType)parts.push('Zieltyp: '+tgtType);
meta.textContent=parts.join(' · ');
item.appendChild(meta);
const connNotes=tt(c.Notes||c.notes||'').trim();
if(connNotes!==''){
const metaBox=document.createElement('div');
metaBox.className='connectionMeta';
metaBox.textContent=connNotes;
item.appendChild(metaBox);
}
item.addEventListener('click',function(){renderConnectionOverlay(deviceIndex,i);});
body.appendChild(item);
}
}
if(incomingConns.length>0){
const stIn=document.createElement('div');
stIn.className='sectionTitle';
stIn.textContent='Eingehende Verbindungen';
body.appendChild(stIn);
for(let i=0;i<incomingConns.length;i++){
const entry=incomingConns[i];
const c=entry.conn;
const item=document.createElement('div');
item.className='connectionItem';
const head=document.createElement('div');
head.className='connectionHeader';
const left=document.createElement('div');
const connType=tt(c.connType||c.service||'Unbekannt');
const typeLbl=document.createElement('div');
typeLbl.className='connectionType';
typeLbl.textContent=resolveServiceLabel(connType);
const tgtEl=document.createElement('div');
tgtEl.className='connectionTarget';
if(entry.sourceHostname)tgtEl.textContent='Quelle: '+entry.sourceHostname;
else tgtEl.textContent='Quelle unbekannt';
left.appendChild(typeLbl);
left.appendChild(tgtEl);
const right=document.createElement('div');
const badge=document.createElement('div');
badge.className='connectionBadge';
const dot=document.createElement('div');
dot.className='connectionColorDot';
dot.style.backgroundColor=getConnectionColor(connType);
badge.appendChild(dot);
const portB=Number(c.port||0);
if(portB>0){
const pb=document.createElement('span');
pb.textContent='Port '+portB;
badge.appendChild(pb);
}
right.appendChild(badge);
head.appendChild(left);
head.appendChild(right);
item.appendChild(head);
const meta=document.createElement('div');
meta.className='connectionMeta';
const parts=[];
parts.push('Typ: '+connType);
const portNum=Number(c.port||0);
if(portNum>0)parts.push('Port: '+portNum);
if(entry.sourceHostname)parts.push('Quelle: '+entry.sourceHostname);
meta.textContent=parts.join(' · ');
item.appendChild(meta);
const connNotes=tt(c.Notes||c.notes||'').trim();
if(connNotes!==''){
const metaBox=document.createElement('div');
metaBox.className='connectionMeta';
metaBox.textContent=connNotes;
item.appendChild(metaBox);
}
item.addEventListener('click',function(){renderConnectionOverlay(entry.sourceIndex,entry.connIndex);});
body.appendChild(item);
}
}
overlay.style.display='block';
}
function renderConnectionOverlay(deviceIndex,connIndex){
const d=deviceData[deviceIndex]||{};
const conns=Array.isArray(d.Connections)?d.Connections:[];
const c=conns[connIndex]||{};
const overlay=document.getElementById('detailOverlay');
const title=document.getElementById('detailOverlayTitle');
const subtitle=document.getElementById('detailOverlaySubtitle');
const badges=document.getElementById('detailBadges');
const body=document.getElementById('detailOverlayBody');
const hnName=tt(d.Hostname||d.hostname||'Unbekannt');
const ip=tt(d.IP||d.ip||'0.0.0.0');
const connType=tt(c.connType||c.service||'Unbekannt');
title.textContent=resolveServiceLabel(connType);
subtitle.textContent='Verbindung · Quelle '+hnName;
badges.innerHTML='';
const typeBadge=document.createElement('div');
typeBadge.className='badge';
const dot1=document.createElement('div');
dot1.className='badgeDot';
dot1.style.backgroundColor=getConnectionColor(connType);
typeBadge.appendChild(dot1);
const lbl1=document.createElement('span');
lbl1.textContent=connType;
typeBadge.appendChild(lbl1);
badges.appendChild(typeBadge);
const portBadgeNum=Number(c.port||0);
if(portBadgeNum>0){
const portBadge=document.createElement('div');
portBadge.className='badge';
const lbl2=document.createElement('span');
lbl2.textContent='Port '+portBadgeNum;
portBadge.appendChild(lbl2);
badges.appendChild(portBadge);
}
body.innerHTML='';
const stInfo=document.createElement('div');
stInfo.className='sectionTitle';
stInfo.textContent='Verbindungsdetails';
body.appendChild(stInfo);
function addRow(l,v){
const row=document.createElement('div');
row.className='infoRow';
const sl=document.createElement('span');
sl.textContent=l;
const sv=document.createElement('span');
sv.textContent=v;
row.appendChild(sl);
row.appendChild(sv);
body.appendChild(row);
}
addRow('Quelle',hnName+' ('+ip+')');
const tgtType=tt(c.targetType||'');
const tgt=tt(c.target||'');
if(tgt){
let info=tgt;
if(tgtType==='hostname'&&Object.prototype.hasOwnProperty.call(deviceIndexByHostname,tgt))info+=' (Gerät vorhanden)';
else if((tgtType==='ip'||!tgtType)&&Object.prototype.hasOwnProperty.call(deviceIndexByIp,tgt))info+=' (Gerät per IP vorhanden)';
addRow('Ziel',info);
}else addRow('Ziel','Unbekannt');
addRow('Zieltyp',tgtType||'-');
const portNum=Number(c.port||0);
if(portNum>0)addRow('Port',String(portNum));
else{
const wk=connPortOf(c);
if(wk>0)addRow('Port (Standard)',String(wk));
}
if(isCableConn(c)){
addRow('Art','Kabel (physisch)');
const vls=tt(c.vlans||'');
if(vls!=='')addRow('Port-VLANs',vls);
}
else{
const tgtIdxFw=resolveTargetIndex(tgtType,tgt);
if(tgtIdxFw!==null){
const fwRes=checkFirewall(deviceIndex,tgtIdxFw,c);
if(fwRes){
const fwd=deviceData[fwRes.fwIndex]||{};
const fwName=tt(fwd.Hostname||fwd.hostname||fwd.IP||fwd.ip||'?');
addRow('Firewall',fwRes.blocked?'blockiert durch '+fwName:'erlaubt ('+fwName+')');
}
}
}
const connNotes=tt(c.Notes||c.notes||'').trim();
if(connNotes!==''){
const nb=document.createElement('div');
nb.className='noteBox';
const nt=document.createElement('div');
nt.className='noteTitle';
nt.textContent='Notizen';
const nc=document.createElement('div');
nc.textContent=connNotes;
nb.appendChild(nt);
nb.appendChild(nc);
body.appendChild(nb);
}
const actions=document.createElement('div');
actions.id='overlayActions';
const delBtn=document.createElement('button');
delBtn.type='button';
delBtn.className='btnDanger btnSmall';
delBtn.textContent='Verbindung löschen';
delBtn.addEventListener('click',function(){deleteConnection(deviceIndex,connIndex);});
actions.appendChild(delBtn);
body.appendChild(actions);
overlay.style.display='block';
}
function hideOverlay(){
document.getElementById('detailOverlay').style.display='none';
}
function selectDevice(index){
const i=Number(index);
if(!Number.isInteger(i)||i<0||i>=deviceData.length)return;
selectedDeviceIndex=i;
selectedEdgeIndex=null;
renderDeviceOverlay(i);
renderMap();
}
function selectConnectionByEdge(edgeIndex){
const e=edges[edgeIndex];
if(!e)return;
selectedDeviceIndex=null;
selectedEdgeIndex=edgeIndex;
renderConnectionOverlay(e.src,e.connIndex);
renderMap();
}
function clearSelection(){
if(selectedDeviceIndex===null&&selectedEdgeIndex===null)return;
selectedDeviceIndex=null;
selectedEdgeIndex=null;
renderMap();
}
function markDirty(){
if(demoActive)return;
dirty=true;
const b=document.getElementById('btnSave');
b.classList.add('dirtyState');
b.textContent='Speichern *';
}
function rebuildAll(){
selectedEdgeIndex=null;
buildIndexes();
applyFilterFromSearch();
buildLayout();
}
function serviceKeys(){
const keys=[];
const labels=appConfig.serviceLabels&&typeof appConfig.serviceLabels==='object'?appConfig.serviceLabels:{};
for(const k in labels){
if(!Object.prototype.hasOwnProperty.call(labels,k))continue;
if(k==='DEFAULT'||k==='Kabel')continue;
keys.push(k);
}
keys.sort();
return keys;
}
function updateFwSection(){
const t=devTypeCombo?devTypeCombo.get():'';
const isFw=t==='Firewall'||getTypeIconPath(t).indexOf('firewall.svg')!==-1;
document.getElementById('fwSection').style.display=isFw?'block':'none';
}
function updateConnKind(){
const cable=document.getElementById('connKind').value==='cable';
document.getElementById('connServiceRow').style.display=cable?'none':'flex';
document.getElementById('connVlanRow').style.display=cable?'flex':'none';
}
function setupCombo(inputId,listId,getOptions,onPick){
const inp=document.getElementById(inputId);
const list=document.getElementById(listId);
let valid='';
function choose(v){
valid=v;
inp.value=v;
list.style.display='none';
if(onPick)onPick(v);
}
function render(filter){
list.innerHTML='';
const f=String(filter||'').toLowerCase();
let n=0;
for(const o of getOptions()){
if(f!==''&&o.label.toLowerCase().indexOf(f)===-1&&o.value.toLowerCase().indexOf(f)===-1)continue;
const it=document.createElement('div');
it.className='comboItem'+(o.value===valid?' active':'');
if(o.icon){
const im=document.createElement('img');
im.src=o.icon;
im.alt='';
it.appendChild(im);
}
const sp=document.createElement('span');
sp.textContent=o.value;
it.appendChild(sp);
if(o.sub){
const su=document.createElement('span');
su.className='comboSub';
su.textContent=o.sub;
it.appendChild(su);
}
it.addEventListener('mousedown',function(ev){ev.preventDefault();choose(o.value);});
list.appendChild(it);
n++;
}
list.style.display=n>0?'block':'none';
}
inp.addEventListener('focus',function(){render('');inp.select();});
inp.addEventListener('input',function(){render(inp.value);});
inp.addEventListener('blur',function(){setTimeout(function(){list.style.display='none';if(inp.value!==valid)inp.value=valid;},120);});
inp.addEventListener('keydown',function(e){
if(e.key==='Enter'){
e.preventDefault();
const first=list.querySelector('.comboItem');
if(first&&list.style.display!=='none')first.dispatchEvent(new MouseEvent('mousedown'));
}else if(e.key==='Escape'&&list.style.display!=='none'){
e.stopPropagation();
list.style.display='none';
inp.value=valid;
}
});
return{
set:function(v){valid=tt(v);inp.value=valid;},
get:function(){return valid;}
};
}
let devTypeCombo=null;
let connServiceCombo=null;
function typeOptions(){
const opts=[];
for(const k in typeCatalog){
if(!Object.prototype.hasOwnProperty.call(typeCatalog,k))continue;
opts.push({value:k,label:k,icon:iconBase+typeCatalog[k].icon});
}
return opts;
}
function serviceOptions(){
const opts=[];
for(const k of serviceKeys()){
const lbl=resolveServiceLabel(k);
opts.push({value:k,label:k+' '+lbl,sub:lbl!==k?lbl:''});
}
return opts;
}
function updateTypeIcon(){
document.getElementById('devTypeIcon').src=getTypeIconPath(devTypeCombo?devTypeCombo.get():'');
}
function fillTypeSelect(current){
devTypeCombo.set(current);
updateTypeIcon();
}
function openDeviceModal(index){
const isNew=index===null||index===undefined||index<0;
editingIndex=isNew?null:index;
const title=document.getElementById('deviceModalTitle');
if(isNew){
title.textContent='Neues Gerät';
document.getElementById('devHostname').value='';
document.getElementById('devIP').value='';
fillTypeSelect('Gerät (Sonstiges)');
document.getElementById('devKind').value='Physisch';
document.getElementById('devRange').value='';
document.getElementById('devFwPolicy').value='allow';
document.getElementById('devFwPorts').value='';
}else{
const d=deviceData[index]||{};
title.textContent='Gerät bearbeiten';
document.getElementById('devHostname').value=tt(d.Hostname||d.hostname||'');
document.getElementById('devIP').value=tt(d.IP||d.ip||'');
fillTypeSelect(tt(d.Type||d.type||''));
const kind=tt(d.Kind||d.kind||'');
document.getElementById('devKind').value=kind==='VM'||kind==='Extern'?kind:'Physisch';
document.getElementById('devRange').value=tt(d.IPRange||'');
document.getElementById('devFwPolicy').value=tt(d.FwPolicy||'')==='block'?'block':'allow';
document.getElementById('devFwPorts').value=Array.isArray(d.FwAllow)?d.FwAllow.join(', '):'';
}
updateFwSection();
hideOverlay();
document.getElementById('deviceModal').style.display='flex';
}
function closeDeviceModal(){
document.getElementById('deviceModal').style.display='none';
editingIndex=null;
}
function applyDeviceModal(){
const hn=document.getElementById('devHostname').value.trim();
const ip=document.getElementById('devIP').value.trim();
if(hn===''&&ip===''){alert('Mindestens Hostname oder IP-Adresse muss gesetzt sein.');return;}
const dev=editingIndex!==null&&deviceData[editingIndex]?deviceData[editingIndex]:{};
const oldHn=tt(dev.Hostname||dev.hostname||'');
const oldIp=tt(dev.IP||dev.ip||'');
if(hn!=='')dev.Hostname=hn;else delete dev.Hostname;
if(ip!=='')dev.IP=ip;else delete dev.IP;
if(editingIndex!==null&&(oldHn!==hn||oldIp!==ip)){
for(const other of deviceData){
if(!other||!Array.isArray(other.Connections))continue;
for(const c of other.Connections){
if(!c)continue;
const tg=tt(c.target||'');
if(tg==='')continue;
if(oldHn!==''&&tg.toLowerCase()===oldHn.toLowerCase()){
c.target=hn!==''?hn:ip;
c.targetType=hn!==''?'hostname':'ip';
}else if(oldIp!==''&&tg===oldIp){
c.target=ip!==''?ip:hn;
c.targetType=ip!==''?'ip':'hostname';
}
}
}
}
dev.Type=devTypeCombo.get()||'Gerät (Sonstiges)';
dev.Kind=document.getElementById('devKind').value;
const range=document.getElementById('devRange').value.trim();
if(range!==''&&range.indexOf('/')!==-1)dev.IPRange=range;else delete dev.IPRange;
const isFw=dev.Type==='Firewall'||getTypeIconPath(dev.Type).indexOf('firewall.svg')!==-1;
if(isFw){
dev.FwPolicy=document.getElementById('devFwPolicy').value==='block'?'block':'allow';
const ports=[];
for(const part of document.getElementById('devFwPorts').value.split(/[,;\s]+/)){
const n=Number(part);
if(Number.isInteger(n)&&n>0&&n<=65535&&ports.indexOf(n)===-1)ports.push(n);
}
dev.FwAllow=ports;
}else{
delete dev.FwPolicy;
delete dev.FwAllow;
}
if(!Array.isArray(dev.Connections))dev.Connections=[];
if(editingIndex===null)deviceData.push(dev);
closeDeviceModal();
markDirty();
rebuildAll();
}
function deleteDevice(index){
const d=deviceData[index]||{};
const hn=tt(d.Hostname||d.hostname||'');
const ip=tt(d.IP||d.ip||'');
if(!confirm('Gerät „'+(hn||ip)+'" löschen (inkl. Verbindungen)?'))return;
cancelConnectMode();
deviceData.splice(index,1);
for(const other of deviceData){
if(!other||!Array.isArray(other.Connections))continue;
other.Connections=other.Connections.filter(function(c){
const tg=tt((c||{}).target||'');
return!(tg!==''&&((hn!==''&&tg.toLowerCase()===hn.toLowerCase())||(ip!==''&&tg===ip)));
});
}
selectedDeviceIndex=null;
hideOverlay();
markDirty();
rebuildAll();
}
let connectKindPreset='service';
function startConnectMode(srcIndex,kind){
connectSourceIndex=srcIndex;
connectKindPreset=kind==='cable'?'cable':'service';
hideOverlay();
document.getElementById('connectBanner').style.display='flex';
}
function cancelConnectMode(){
connectSourceIndex=null;
document.getElementById('connectBanner').style.display='none';
}
function handleNodeClick(i){
if(connectSourceIndex!==null){
if(i===connectSourceIndex)return;
openConnModal(connectSourceIndex,i);
return;
}
selectDevice(i);
}
function openConnModal(src,tgt){
pendingConn={src:src,tgt:tgt};
const s=deviceData[src]||{};
const t=deviceData[tgt]||{};
const sName=tt(s.Hostname||s.hostname||s.IP||s.ip||'?');
const tName=tt(t.Hostname||t.hostname||t.IP||t.ip||'?');
document.getElementById('connModalInfo').textContent=sName+' → '+tName;
connServiceCombo.set('');
document.getElementById('connKind').value=connectKindPreset;
updateConnKind();
document.getElementById('connPort').value='';
document.getElementById('connVlans').value='';
document.getElementById('connModal').style.display='flex';
}
function closeConnModal(){
document.getElementById('connModal').style.display='none';
pendingConn=null;
}
function applyConnModal(){
if(!pendingConn)return;
const d=deviceData[pendingConn.src];
if(!d)return;
if(!Array.isArray(d.Connections))d.Connections=[];
const t=deviceData[pendingConn.tgt]||{};
const hn=tt(t.Hostname||t.hostname||'');
const ip=tt(t.IP||t.ip||'');
const obj={};
if(document.getElementById('connKind').value==='cable'){
obj.connType='Kabel';
const vl=document.getElementById('connVlans').value.trim();
if(vl!=='')obj.vlans=vl;
}else{
const svc=connServiceCombo.get();
if(svc!=='')obj.connType=svc;
const portStr=document.getElementById('connPort').value.trim();
if(portStr!==''){
const n=Number(portStr);
if(!Number.isNaN(n)&&n>0)obj.port=n;
}
}
obj.target=hn||ip;
obj.targetType=hn!==''?'hostname':'ip';
d.Connections.push(obj);
const srcIdx=pendingConn.src;
closeConnModal();
cancelConnectMode();
markDirty();
rebuildAll();
selectDevice(srcIdx);
}
function deleteConnection(devIndex,connIndex){
const d=deviceData[devIndex];
if(!d||!Array.isArray(d.Connections))return;
if(!confirm('Verbindung wirklich löschen?'))return;
d.Connections.splice(connIndex,1);
markDirty();
rebuildAll();
selectDevice(devIndex);
}
function guessTypeFromName(name){
const n=String(name).toLowerCase();
const rules=[
[/^(fw|fgt|asa|pfsense|opn)/,'Firewall'],
[/^(sw|switch)/,'Switch'],
[/^(rt|router|edge)/,'Router'],
[/^(gw|gateway)/,'Router'],
[/^(ap[0-9-]|ap$|wlan|wifi)/,'Access Point'],
[/^(esx|pve|prox|hv[0-9-]|xen|kvm|vmh)/,'Hypervisor'],
[/^dc[0-9-]/,'Domain-Controller'],
[/^(db|sql|ora|pg|mysql)/,'Datenbank'],
[/^(nas|stor|san)/,'Storage/NAS'],
[/^(prn|print|drucker)/,'Drucker'],
[/^(cam|kamera|nvr)/,'Kamera'],
[/^(tel|voip|pbx)/,'VoIP-Telefon'],
[/^(usv|ups)/,'USV'],
[/^(mon|zbx|prtg|nagios|graf)/,'Monitoring'],
[/^(mail|mx[0-9-]|smtp|exch)/,'Mail-Server'],
[/^(web|www|nginx|apache)/,'Web-Server'],
[/^dns/,'DNS-Server'],
[/^dhcp/,'DHCP-Server'],
[/^(bkp|backup|veeam)/,'Backup'],
[/^(inet|wan|isp|provider)/,'Internet/Provider'],
[/^(hotspot|mifi)/,'Hotspot'],
[/^(nb|lt|laptop|note)/,'Laptop'],
[/^(handy|iphone|android|mobil|smart)/,'Smartphone'],
[/^(tab|ipad)/,'Tablet'],
[/^(pc|ws[0-9-]|wks|desk|client)/,'PC'],
[/^(srv|server|host)/,'Server']
];
for(const r of rules){if(r[0].test(n))return r[1];}
return null;
}
function guessTypeFromText(text){
const file=getDefaultTypeIcon(String(text));
if(file!=='device.svg'){
for(const k in typeCatalog){
if(!Object.prototype.hasOwnProperty.call(typeCatalog,k))continue;
if(typeCatalog[k].icon===file)return k;
}
}
return null;
}
function deviceExists(hostname,ip){
for(const d of deviceData){
const dh=tt((d||{}).Hostname||(d||{}).hostname||'');
const di=tt((d||{}).IP||(d||{}).ip||'');
if(hostname!==''&&dh!==''&&dh.toLowerCase()===hostname.toLowerCase())return true;
if(ip!==''&&di!==''&&di===ip)return true;
}
return false;
}
function parseQuickLines(text){
const out=[];
const seenH={};
const seenI={};
const lines=String(text).split(/\r\n|\n|\r/);
for(const line of lines){
const lt=line.trim();
if(lt===''||lt.charAt(0)==='#')continue;
const tokens=lt.split(/[\s,;\t]+/).filter(Boolean);
let ip='';
let hostname='';
const rest=[];
for(const tk of tokens){
if(ip===''&&/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(tk)&&ipToInt(tk)!==null)ip=tk;
else if(hostname==='')hostname=tk;
else rest.push(tk);
}
if(hostname===''&&ip==='')continue;
let type=null;
if(rest.length>0)type=guessTypeFromText(rest.join(' '));
if(!type&&hostname!=='')type=guessTypeFromName(hostname)||guessTypeFromText(hostname);
if(!type)type='Gerät (Sonstiges)';
const dupInBatch=(hostname!==''&&seenH[hostname.toLowerCase()])||(ip!==''&&seenI[ip]);
if(hostname!=='')seenH[hostname.toLowerCase()]=true;
if(ip!=='')seenI[ip]=true;
out.push({Hostname:hostname,IP:ip,Type:type,exists:dupInBatch||deviceExists(hostname,ip)});
}
return out;
}
function renderQuickPreview(){
const list=parseQuickLines(document.getElementById('quickText').value);
const box=document.getElementById('quickPreview');
box.innerHTML='';
for(const item of list){
const row=document.createElement('div');
row.className='quickRow'+(item.exists?' qskip':'');
const img=document.createElement('img');
img.src=getTypeIconPath(item.Type);
img.alt='';
row.appendChild(img);
const qh=document.createElement('span');
qh.className='qh';
qh.textContent=item.Hostname||'–';
row.appendChild(qh);
const qi=document.createElement('span');
qi.className='qi';
qi.textContent=item.IP||'–';
row.appendChild(qi);
const qt=document.createElement('span');
qt.className='qt';
qt.textContent='→ '+item.Type;
row.appendChild(qt);
if(item.exists){
const qs=document.createElement('span');
qs.className='qs';
qs.textContent='existiert bereits – wird übersprungen';
row.appendChild(qs);
}
box.appendChild(row);
}
return list;
}
function openQuickModal(){
document.getElementById('quickText').value='';
document.getElementById('quickPreview').innerHTML='';
document.getElementById('quickModal').style.display='flex';
document.getElementById('quickText').focus();
}
function closeQuickModal(){
document.getElementById('quickModal').style.display='none';
}
function applyQuickModal(){
const list=parseQuickLines(document.getElementById('quickText').value);
let added=0;
for(const item of list){
if(item.exists)continue;
const dev={Type:item.Type,Kind:'Physisch',Connections:[]};
if(item.Hostname!=='')dev.Hostname=item.Hostname;
if(item.IP!=='')dev.IP=item.IP;
deviceData.push(dev);
added++;
}
closeQuickModal();
if(added>0){
markDirty();
rebuildAll();
}
}
function saveConfigNow(){
if(demoActive)return;
if(totpSetup)return;
const code=(document.getElementById('totpInput').value||'').replace(/\s+/g,'');
if(!/^\d{6}$/.test(code)){
alert('Bitte 6-stelligen TOTP-Code eingeben.');
document.getElementById('totpInput').focus();
return;
}
document.getElementById('totpHidden').value=code;
document.getElementById('config_json').value=JSON.stringify(appConfig);
dirty=false;
document.getElementById('saveForm').submit();
}
function hideCtxMenu(){
document.getElementById('ctxMenu').style.display='none';
}
function showCtxMenu(ev,items){
const menu=document.getElementById('ctxMenu');
menu.innerHTML='';
for(const it of items){
if(it.sep){
const s=document.createElement('div');
s.className='ctxSep';
menu.appendChild(s);
continue;
}
if(it.title){
const t=document.createElement('div');
t.className='ctxTitle';
t.textContent=it.title;
menu.appendChild(t);
continue;
}
const el=document.createElement('div');
el.className='ctxItem'+(it.danger?' danger':'');
el.textContent=it.label;
el.addEventListener('click',function(){hideCtxMenu();it.fn();});
menu.appendChild(el);
}
menu.style.display='block';
const mw=menu.offsetWidth;
const mh=menu.offsetHeight;
let x=ev.clientX;
let y=ev.clientY;
if(x+mw>window.innerWidth-8)x=window.innerWidth-mw-8;
if(y+mh>window.innerHeight-8)y=window.innerHeight-mh-8;
menu.style.left=x+'px';
menu.style.top=y+'px';
}
function showNodeMenu(ev,i){
const d=deviceData[i]||{};
const name=tt(d.Hostname||d.hostname||d.IP||d.ip||'Gerät');
showCtxMenu(ev,[
{title:name},
{label:'Details anzeigen',fn:function(){selectDevice(i);}},
{label:'Bearbeiten…',fn:function(){openDeviceModal(i);}},
{sep:true},
{label:'Dienst verbinden…',fn:function(){startConnectMode(i,'service');}},
{label:'Kabel verbinden…',fn:function(){startConnectMode(i,'cable');}},
{sep:true},
{label:'Gerät löschen',danger:true,fn:function(){deleteDevice(i);}}
]);
}
function showEdgeMenu(ev,edgeIndex){
const e=edges[edgeIndex];
if(!e)return;
showCtxMenu(ev,[
{title:resolveServiceLabel(e.connType)},
{label:'Details anzeigen',fn:function(){selectConnectionByEdge(edgeIndex);}},
{sep:true},
{label:'Verbindung löschen',danger:true,fn:function(){deleteConnection(e.src,e.connIndex);}}
]);
}
function showCanvasMenu(ev){
showCtxMenu(ev,[
{label:'+ Neues Gerät…',fn:function(){openDeviceModal(null);}},
{label:'⚡ Schnell einfügen…',fn:function(){openQuickModal();}},
{sep:true},
{label:'Ansicht zurücksetzen',fn:function(){mapScale=1;mapOffsetX=0;mapOffsetY=0;updateMapTransform();}},
{label:'Speichern',fn:function(){saveConfigNow();}}
]);
}
function qrMatrix(text){
const GEXP=new Array(256);
const GLOG=new Array(256);
let v=1;
for(let i=0;i<255;i++){GEXP[i]=v;GLOG[v]=i;v=v<<1;if(v&0x100)v^=0x11d;}
GEXP[255]=GEXP[0];
function gmul(a,b){if(a===0||b===0)return 0;return GEXP[(GLOG[a]+GLOG[b])%255];}
const bytes=[];
for(let i=0;i<text.length;i++){
const c=text.charCodeAt(i);
if(c<128)bytes.push(c);
else if(c<2048){bytes.push(192|(c>>6));bytes.push(128|(c&63));}
else{bytes.push(224|(c>>12));bytes.push(128|((c>>6)&63));bytes.push(128|(c&63));}
}
const versions=[
{v:1,size:21,total:26,ec:7,blocks:1,align:0},
{v:2,size:25,total:44,ec:10,blocks:1,align:18},
{v:3,size:29,total:70,ec:15,blocks:1,align:22},
{v:4,size:33,total:100,ec:20,blocks:1,align:26},
{v:5,size:37,total:134,ec:26,blocks:1,align:30},
{v:6,size:41,total:172,ec:36,blocks:2,align:34}
];
let spec=null;
for(const sp of versions){
const dataCw=sp.total-sp.ec;
if(bytes.length+2<=dataCw){spec={size:sp.size,ec:sp.ec,blocks:sp.blocks,align:sp.align,dataCw:dataCw};break;}
}
if(!spec)return null;
const bits=[];
function put(val,len){for(let i=len-1;i>=0;i--)bits.push((val>>i)&1);}
put(4,4);
put(bytes.length,8);
for(const b of bytes)put(b,8);
const capBits=spec.dataCw*8;
for(let i=0;i<4&&bits.length<capBits;i++)bits.push(0);
while(bits.length%8!==0)bits.push(0);
const dataBytes=[];
for(let i=0;i<bits.length;i+=8){
let bb=0;
for(let j=0;j<8;j++)bb=(bb<<1)|bits[i+j];
dataBytes.push(bb);
}
const pads=[0xEC,0x11];
let pi=0;
while(dataBytes.length<spec.dataCw){dataBytes.push(pads[pi%2]);pi++;}
function rsEncode(data,ecLen){
let gen=[1];
for(let i=0;i<ecLen;i++){
const next=new Array(gen.length+1).fill(0);
for(let j=0;j<gen.length;j++){
next[j]^=gmul(gen[j],GEXP[i]);
next[j+1]^=gen[j];
}
gen=next;
}
gen.reverse();
const res=data.concat(new Array(ecLen).fill(0));
for(let i=0;i<data.length;i++){
const f=res[i];
if(f===0)continue;
for(let j=0;j<gen.length;j++)res[i+j]^=gmul(gen[j],f);
}
return res.slice(data.length);
}
const nBlocks=spec.blocks;
const perBlock=spec.dataCw/nBlocks;
const ecPerBlock=spec.ec/nBlocks;
const dataBlocks=[];
const ecBlocks=[];
for(let b=0;b<nBlocks;b++){
const chunk=dataBytes.slice(b*perBlock,(b+1)*perBlock);
dataBlocks.push(chunk);
ecBlocks.push(rsEncode(chunk,ecPerBlock));
}
const finalBytes=[];
for(let i=0;i<perBlock;i++)for(let b=0;b<nBlocks;b++)finalBytes.push(dataBlocks[b][i]);
for(let i=0;i<ecPerBlock;i++)for(let b=0;b<nBlocks;b++)finalBytes.push(ecBlocks[b][i]);
const size=spec.size;
const m=[];
const used=[];
for(let r=0;r<size;r++){m.push(new Array(size).fill(false));used.push(new Array(size).fill(false));}
function set(r,c,val){m[r][c]=val;used[r][c]=true;}
function finder(r,c){
for(let i=-1;i<=7;i++)for(let j=-1;j<=7;j++){
const rr=r+i,cc=c+j;
if(rr<0||rr>=size||cc<0||cc>=size)continue;
const on=(i>=0&&i<=6&&(j===0||j===6))||(j>=0&&j<=6&&(i===0||i===6))||(i>=2&&i<=4&&j>=2&&j<=4);
set(rr,cc,on);
}
}
finder(0,0);
finder(0,size-7);
finder(size-7,0);
if(spec.align>0){
const ac=spec.align;
for(let i=-2;i<=2;i++)for(let j=-2;j<=2;j++){
const on=Math.max(Math.abs(i),Math.abs(j))!==1;
set(ac+i,ac+j,on);
}
}
for(let i=8;i<size-8;i++){
if(!used[6][i])set(6,i,i%2===0);
if(!used[i][6])set(i,6,i%2===0);
}
set(size-8,8,true);
const fmtBits=[1,1,1,0,1,1,1,1,1,0,0,0,1,0,0];
for(let i=0;i<6;i++)set(8,i,fmtBits[i]===1);
set(8,7,fmtBits[6]===1);
set(8,8,fmtBits[7]===1);
set(7,8,fmtBits[8]===1);
for(let i=9;i<15;i++)set(14-i,8,fmtBits[i]===1);
for(let i=0;i<7;i++)set(size-1-i,8,fmtBits[i]===1);
for(let i=7;i<15;i++)set(8,size-15+i,fmtBits[i]===1);
let bitIdx=0;
const totalBits=finalBytes.length*8;
function nextBit(){
if(bitIdx>=totalBits)return 0;
const byte=finalBytes[bitIdx>>3];
const bit=(byte>>(7-(bitIdx&7)))&1;
bitIdx++;
return bit;
}
let col=size-1;
let upward=true;
while(col>0){
if(col===6)col--;
for(let i=0;i<size;i++){
const r=upward?size-1-i:i;
for(let cc=0;cc<2;cc++){
const c=col-cc;
if(used[r][c])continue;
let bit=nextBit();
if((r+c)%2===0)bit=bit^1;
m[r][c]=bit===1;
used[r][c]=true;
}
}
upward=!upward;
col-=2;
}
return m;
}
function renderTotpQr(){
if(!totpSetup)return;
const canvas=document.getElementById('totpQr');
if(!canvas)return;
const mtx=qrMatrix(totpSetup.uri);
if(!mtx){canvas.style.display='none';return;}
const n=mtx.length;
const scale=5;
const quiet=4;
canvas.width=(n+quiet*2)*scale;
canvas.height=(n+quiet*2)*scale;
const g=canvas.getContext('2d');
g.fillStyle='#ffffff';
g.fillRect(0,0,canvas.width,canvas.height);
g.fillStyle='#000000';
for(let r=0;r<n;r++)for(let c=0;c<n;c++){
if(mtx[r][c])g.fillRect((c+quiet)*scale,(r+quiet)*scale,scale,scale);
}
}
function setupManage(){
document.getElementById('btnAddDevice').addEventListener('click',function(){openDeviceModal(null);});
document.getElementById('btnSave').addEventListener('click',saveConfigNow);
document.getElementById('btnDeviceClose').addEventListener('click',closeDeviceModal);
document.getElementById('btnDeviceApply').addEventListener('click',applyDeviceModal);
document.getElementById('btnDeviceDelete').addEventListener('click',function(){
if(editingIndex===null){closeDeviceModal();return;}
const idx=editingIndex;
closeDeviceModal();
deleteDevice(idx);
});
devTypeCombo=setupCombo('devType','devTypeOpts',typeOptions,function(){updateTypeIcon();updateFwSection();});
connServiceCombo=setupCombo('connService','connServiceOpts',serviceOptions,null);
document.getElementById('connKind').addEventListener('change',updateConnKind);
document.getElementById('btnConnClose').addEventListener('click',closeConnModal);
document.getElementById('btnConnCancel').addEventListener('click',closeConnModal);
document.getElementById('btnConnApply').addEventListener('click',applyConnModal);
document.getElementById('btnConnectCancel').addEventListener('click',cancelConnectMode);
function backdropClose(id,closeFn){
const el=document.getElementById(id);
let downOnBackdrop=false;
el.addEventListener('mousedown',function(e){downOnBackdrop=e.target===el;});
el.addEventListener('click',function(e){if(e.target===el&&downOnBackdrop)closeFn();});
}
backdropClose('deviceModal',closeDeviceModal);
backdropClose('connModal',closeConnModal);
backdropClose('quickModal',closeQuickModal);
document.addEventListener('keydown',function(e){
if(e.key!=='Escape')return;
closeDeviceModal();
closeConnModal();
closeQuickModal();
cancelConnectMode();
hideCtxMenu();
});
document.addEventListener('click',hideCtxMenu);
document.getElementById('mapSvg').addEventListener('contextmenu',function(e){
e.preventDefault();
showCanvasMenu(e);
});
const layerMap={lyVlan:'vlan',lyCable:'cable',lySvc:'svc',lyBlocked:'blocked',lyHost:'host'};
for(const id in layerMap){
if(!Object.prototype.hasOwnProperty.call(layerMap,id))continue;
document.getElementById(id).addEventListener('change',(function(key,el){
return function(){
layers[key]=el.checked;
if(selectedEdgeIndex!==null){
const e=edges[selectedEdgeIndex];
if(!e||(e.cable&&!layers.cable)||(!e.cable&&!layers.svc)||(e.blocked&&!layers.blocked)){
selectedEdgeIndex=null;
hideOverlay();
}
}
renderMap();
};
})(layerMap[id],document.getElementById(id)));
}
document.getElementById('viewModeSel').addEventListener('change',function(){
viewMode=this.value;
clearSelection();
hideOverlay();
buildLayout();
});
document.getElementById('btnQuickAdd').addEventListener('click',openQuickModal);
document.getElementById('btnQuickClose').addEventListener('click',closeQuickModal);
document.getElementById('btnQuickCancel').addEventListener('click',closeQuickModal);
document.getElementById('btnQuickApply').addEventListener('click',applyQuickModal);
document.getElementById('quickText').addEventListener('input',renderQuickPreview);
document.getElementById('totpInput').addEventListener('keydown',function(e){
if(e.key==='Enter')saveConfigNow();
});
if(totpSetup)renderTotpQr();
if(demoActive){
const b=document.getElementById('btnSave');
b.disabled=true;
b.textContent='Beispiel';
document.getElementById('totpInput').disabled=true;
const dn=document.createElement('div');
dn.className='notice ok';
dn.textContent='Beispiel-Netzwerk (temporär) – Neuladen zeigt wieder dein Netz.';
document.body.appendChild(dn);
}
if(initialDirty)markDirty();
window.addEventListener('beforeunload',function(e){
if(!dirty)return;
e.preventDefault();
e.returnValue='';
});
const notice=document.getElementById('saveNotice');
if(notice){
notice.style.cursor='pointer';
notice.title='Klicken zum Schließen';
notice.addEventListener('click',function(){notice.style.display='none';});
if(notice.classList.contains('ok'))setTimeout(function(){notice.style.display='none';},2500);
}
}
function setupSearch(){
const input=document.getElementById('searchInput');
input.addEventListener('input',function(){
selectedDeviceIndex=null;
selectedEdgeIndex=null;
applyFilterFromSearch();
buildLayout();
hideOverlay();
});
}
function setupOverlay(){
document.getElementById('detailOverlayClose').addEventListener('click',function(){hideOverlay();});
document.addEventListener('keydown',function(ev){if(ev.key==='Escape')hideOverlay();});
}
function setupPanZoom(){
const svg=document.getElementById('mapSvg');
svg.addEventListener('wheel',function(ev){
ev.preventDefault();
const rect=svg.getBoundingClientRect();
const cx=ev.clientX-rect.left;
const cy=ev.clientY-rect.top;
const delta=ev.deltaY;
const factor=delta>0?0.9:1.1;
let newScale=mapScale*factor;
if(newScale<0.4)newScale=0.4;
if(newScale>2.5)newScale=2.5;
const ratio=newScale/mapScale;
mapOffsetX=cx-(cx-mapOffsetX)*ratio;
mapOffsetY=cy-(cy-mapOffsetY)*ratio;
mapScale=newScale;
updateMapTransform();
},{passive:false});
let panMoved=false;
svg.addEventListener('mousedown',function(ev){
isPanning=true;
panMoved=false;
lastPanX=ev.clientX;
lastPanY=ev.clientY;
});
window.addEventListener('mousemove',function(ev){
if(!isPanning)return;
const dx=ev.clientX-lastPanX;
const dy=ev.clientY-lastPanY;
if(Math.abs(dx)+Math.abs(dy)>2)panMoved=true;
lastPanX=ev.clientX;
lastPanY=ev.clientY;
mapOffsetX+=dx;
mapOffsetY+=dy;
updateMapTransform();
});
window.addEventListener('mouseup',function(){isPanning=false;});
svg.addEventListener('click',function(){
if(panMoved){panMoved=false;return;}
hideOverlay();
clearSelection();
});
}
function setupResize(){
if(typeof ResizeObserver==='undefined')return;
const shell=document.getElementById('mapShell');
const obs=new ResizeObserver(function(){buildLayout();});
obs.observe(shell);
}
function init(){
visibleDevice=new Array(deviceData.length);
for(let i=0;i<visibleDevice.length;i++)visibleDevice[i]=true;
buildIndexes();
applyFilterFromSearch();
buildLayout();
setupSearch();
setupOverlay();
setupPanZoom();
setupResize();
setupManage();
}
document.addEventListener('DOMContentLoaded',init);
})();
</script>
</body>
</html>
